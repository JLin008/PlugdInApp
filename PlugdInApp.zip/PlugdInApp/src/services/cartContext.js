import React, { createContext, useContext, useState, useEffect } from 'react'
import { cartService } from './cartService'
import { profileService } from './profileService'
import { useAuth } from './authContext'
import { supabase } from './supabase'

const CartContext = createContext({})

export const CartProvider = ({ children }) => {
  const [cartCount, setCartCount] = useState(0)
  const [profile, setProfile] = useState(null)
  const { user } = useAuth()

  const refreshCartCount = async () => {
    if (!user) {
      setCartCount(0)
      return
    }
    
    try {
      const count = await cartService.getCartCount()
      setCartCount(count)
    } catch (error) {
      console.error('Error refreshing cart count:', error)
    }
  }

  const refreshProfile = async () => {
    if (!user) {
      setProfile(null)
      return
    }
    
    try {
      const profileData = await profileService.getProfile(user.id)
      setProfile(profileData)
    } catch (error) {
      console.error('Error fetching profile:', error)
    }
  }

  useEffect(() => {
    refreshCartCount()
    refreshProfile()
    
    if (user) {
      // Subscribe to cart changes
      const cartSubscription = supabase
        .channel(`cart_changes_${user.id}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'cart_items',
            filter: `user_id=eq.${user.id}`
          },
          () => {
            refreshCartCount()
          }
        )
        .subscribe()

      return () => {
        supabase.removeChannel(cartSubscription)
      }
    }
  }, [user])

  const addToCart = async (productId, quantity = 1) => {
    const result = await cartService.addToCart(productId, quantity)
    await refreshCartCount()
    return result
  }

  const updateCartQuantity = async (productId, newQuantity) => {
    if (!user) return
    
    try {
      const result = await cartService.updateCartQuantity(productId, newQuantity)
      await refreshCartCount()
      return result
    } catch (error) {
      console.error('Error updating cart quantity:', error)
      throw error
    }
  }

  const removeFromCart = async (productId) => {
    if (!user) return
    
    try {
      const result = await cartService.removeFromCartByProductId(productId)
      await refreshCartCount()
      return result
    } catch (error) {
      console.error('Error removing from cart:', error)
      throw error
    }
  }

  const updateProfile = async (updates) => {
    if (!user) return
    
    try {
      const updatedProfile = await profileService.updateProfile(user.id, updates)
      setProfile(updatedProfile)
      return updatedProfile
    } catch (error) {
      console.error('Error updating profile:', error)
      throw error
    }
  }

  return (
    <CartContext.Provider value={{ 
      cartCount, 
      refreshCartCount,
      addToCart,
      updateCartQuantity,
      removeFromCart,
      profile,
      refreshProfile,
      updateProfile
    }}>
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => {
  const context = useContext(CartContext)
  if (!context) {
    throw new Error('useCart must be used within CartProvider')
  }
  return context
}