import { supabase } from './supabase'
import * as Notifications from 'expo-notifications'
import * as Device from 'expo-device'
import { Platform } from 'react-native'
import Constants from 'expo-constants'

export const notificationService = {
  // Get project ID from app.json
  getProjectId() {
    return Constants.expoConfig?.extra?.eas?.projectId || Constants.easConfig?.projectId
  },

  // Register device for push notifications
  async registerForPushNotifications() {
    let token;

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF69B4',
      });
    }

    if (Device.isDevice) {
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      
      if (finalStatus !== 'granted') {
        console.log('Failed to get push token for push notification!');
        return null;
      }
      
      const projectId = this.getProjectId();
      if (!projectId) {
        console.log('No project ID found. Please run: npx eas-cli@latest init');
        return null;
      }
      
      token = (await Notifications.getExpoPushTokenAsync({
        projectId: projectId
      })).data;
      
      console.log('Push token:', token);
      
      // Save token to database
      await this.savePushToken(token);
      
      return token;
    } else {
      console.log('Must use physical device for Push Notifications');
      return null;
    }
  },

  // Save push token to database
  async savePushToken(token) {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      
      const { error } = await supabase
        .from('push_tokens')
        .upsert([{
          token: token,
          user_id: user?.id || null,
          device_type: Platform.OS,
          is_active: true,
          updated_at: new Date().toISOString()
        }], {
          onConflict: 'token'
        })

      if (error) {
        console.error('Error saving push token:', error)
      }
    } catch (error) {
      console.error('Error in savePushToken:', error)
    }
  },

  // Remove push token (on logout)
  async removePushToken() {
    try {
      const projectId = this.getProjectId();
      if (!projectId) return;
      
      const token = (await Notifications.getExpoPushTokenAsync({
        projectId: projectId
      })).data;
      
      const { error } = await supabase
        .from('push_tokens')
        .update({ is_active: false })
        .eq('token', token)

      if (error) {
        console.error('Error removing push token:', error)
      }
    } catch (error) {
      console.error('Error in removePushToken:', error)
    }
  }
}