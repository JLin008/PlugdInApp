import { supabase } from './supabase'

export const orderService = {
  // Create a new order
  async createOrder(orderData) {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      
      const { data, error } = await supabase
        .from('orders')
        .insert([{
          customer_name: orderData.customerName,
          customer_email: user?.email || orderData.customerEmail,
          delivery_address: orderData.deliveryAddress,
          items: orderData.items,
          subtotal: orderData.subtotal,
          delivery_fee: orderData.deliveryFee || 4.99,
          tax: orderData.tax,
          discount_amount: orderData.discountAmount || 0,
          total: orderData.total,
          user_id: user?.id || null
        }])
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error creating order:', error)
      throw error
    }
  },

  // Get all orders (for dispensary admin)
  async getAllOrders() {
    try {
      // First check if user is dispensary admin
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error('Not authenticated')

      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error fetching orders:', error)
      throw error
    }
  },

  // Get orders by status
  async getOrdersByStatus(status) {
    try {
      const query = supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })

      if (status && status !== 'all') {
        query.eq('status', status)
      }

      const { data, error } = await query

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error fetching orders by status:', error)
      throw error
    }
  },

  // Search orders by order number
  async searchOrders(searchTerm) {
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .ilike('order_number', `%${searchTerm}%`)
        .order('created_at', { ascending: false })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error searching orders:', error)
      throw error
    }
  },

  // Update order status
  async updateOrderStatus(orderId, newStatus) {
    try {
      const { data, error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error) {
      console.error('Error updating order status:', error)
      throw error
    }
  },

  // Get dashboard metrics
  async getDashboardMetrics() {
    try {
      // Get today's orders count
      const { data: todaysOrders, error: todaysError } = await supabase
        .from('todays_orders_count')
        .select('count')
        .single()

      // Get pending orders count
      const { data: pendingOrders, error: pendingError } = await supabase
        .from('pending_orders_count')
        .select('count')
        .single()

      // Get completed orders count
      const { data: completedOrders, error: completedError } = await supabase
        .from('completed_orders_count')
        .select('count')
        .single()

      if (todaysError || pendingError || completedError) {
        throw new Error('Error fetching metrics')
      }

      return {
        todaysOrders: todaysOrders?.count || 0,
        pendingOrders: pendingOrders?.count || 0,
        completedOrders: completedOrders?.count || 0
      }
    } catch (error) {
      console.error('Error fetching dashboard metrics:', error)
      return {
        todaysOrders: 0,
        pendingOrders: 0,
        completedOrders: 0
      }
    }
  },

  // Get weekly orders trend
  async getWeeklyOrdersTrend() {
    try {
      const { data, error } = await supabase
        .from('weekly_orders_trend')
        .select('*')

      if (error) throw error

      // Fill in missing days with 0 orders
      const last7Days = []
      for (let i = 6; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)
        const dateStr = date.toISOString().split('T')[0]
        
        const dayData = data?.find(d => d.order_date === dateStr)
        last7Days.push({
          date: dateStr,
          day: date.toLocaleDateString('en-US', { weekday: 'short' }),
          count: dayData?.order_count || 0
        })
      }

      return last7Days
    } catch (error) {
      console.error('Error fetching weekly trend:', error)
      return []
    }
  },

  // Get low stock products
  async getLowStockProducts() {
    try {
      // Query products table directly instead of using view
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .lt('stock', 20)  // Less than 20 stock
        .order('stock', { ascending: true })

      if (error) throw error
      return data || []
    } catch (error) {
      console.error('Error fetching low stock products:', error)
      return []
    }
  },

  // Get total revenue
  async getTotalRevenue() {
    try {
      const { data, error } = await supabase
        .from('total_revenue')
        .select('revenue')
        .single()

      if (error) throw error
      return data?.revenue || 0
    } catch (error) {
      console.error('Error fetching total revenue:', error)
      return 0
    }
  },

  // Get products sold count
  async getProductsSoldCount() {
    try {
      const { data, error } = await supabase
        .from('products_sold_count')
        .select('count')
        .single()

      if (error) throw error
      return data?.count || 0
    } catch (error) {
      console.error('Error fetching products sold:', error)
      return 0
    }
  },

  // Get daily revenue for graph
  async getDailyRevenue() {
    try {
      const { data, error } = await supabase
        .from('daily_revenue')
        .select('*')
        .order('date', { ascending: true })

      if (error) throw error

      // Fill in missing days with 0 revenue
      const last7Days = []
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
      
      // Generate all days for the last week
      for (let i = 6; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)
        const dateStr = date.toISOString().split('T')[0]
        const dayName = dayNames[date.getDay()]
        
        const dayData = data?.find(d => d.date === dateStr)
        last7Days.push({
          date: dateStr,
          day: dayName,
          revenue: parseFloat(dayData?.revenue) || 0
        })
      }

      return last7Days
    } catch (error) {
      console.error('Error fetching daily revenue:', error)
      
      // Return empty week on error
      const last7Days = []
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
      
      for (let i = 6; i >= 0; i--) {
        const date = new Date()
        date.setDate(date.getDate() - i)
        const dayName = dayNames[date.getDay()]
        
        last7Days.push({
          date: date.toISOString().split('T')[0],
          day: dayName,
          revenue: 0
        })
      }
      
      return last7Days
    }
  },

  // Subscribe to order updates
  subscribeToOrders(callback) {
    return supabase
      .channel('orders_channel')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        (payload) => {
          callback(payload)
        }
      )
      .subscribe()
  }
}