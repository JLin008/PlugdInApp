import { supabase } from './supabase'

export const cartService = {
  // Get all cart items for the current user
  async getCartItems() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return []

    const { data, error } = await supabase
      .from('cart_items')
      .select(`
        id,
        quantity,
        product_id,
        products (
          id,
          name,
          brand,
          price,
          discount,
          image_url,
          thc_percent,
          cbd_percent,
          type
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching cart:', error)
      return []
    }

    return data || []
  },

  // Add item to cart
  async addToCart(productId, quantity = 1) {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Check if item already exists in cart
    const { data: existing, error: checkError } = await supabase
      .from('cart_items')
      .select('id, quantity')
      .eq('user_id', user.id)
      .eq('product_id', productId)
      .maybeSingle()

    if (checkError && checkError.code !== 'PGRST116') {
      throw checkError
    }

    if (existing) {
      // Update quantity if item exists
      const { error } = await supabase
        .from('cart_items')
        .update({ quantity: existing.quantity + quantity })
        .eq('id', existing.id)

      if (error) {
        throw error
      }
      return { success: true, action: 'updated' }
    } else {
      // Add new item to cart
      const { data, error } = await supabase
        .from('cart_items')
        .insert([{
          user_id: user.id,
          product_id: productId,
          quantity: quantity
        }])

      if (error) {
        throw error
      }
      return { success: true, action: 'added' }
    }
  },

  // Update cart item quantity by product ID
  async updateCartQuantity(productId, newQuantity) {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    if (newQuantity === 0) {
      return this.removeFromCartByProductId(productId)
    }

    // Check if item exists
    const { data: existing, error: checkError } = await supabase
      .from('cart_items')
      .select('id')
      .eq('user_id', user.id)
      .eq('product_id', productId)
      .maybeSingle()

    if (checkError && checkError.code !== 'PGRST116') {
      throw checkError
    }

    if (existing) {
      // Update existing item
      const { error } = await supabase
        .from('cart_items')
        .update({ quantity: newQuantity })
        .eq('user_id', user.id)
        .eq('product_id', productId)

      if (error) throw error
      return { success: true }
    } else {
      // Add new item if it doesn't exist
      const { error } = await supabase
        .from('cart_items')
        .insert([{
          user_id: user.id,
          product_id: productId,
          quantity: newQuantity
        }])

      if (error) throw error
      return { success: true }
    }
  },

  // Update cart item quantity by cart item ID
  async updateQuantity(cartItemId, newQuantity) {
    if (newQuantity < 1) {
      return this.removeFromCart(cartItemId)
    }

    const { error } = await supabase
      .from('cart_items')
      .update({ quantity: newQuantity })
      .eq('id', cartItemId)

    if (error) throw error
    return { success: true }
  },

  // Remove item from cart by cart item ID
  async removeFromCart(cartItemId) {
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('id', cartItemId)

    if (error) throw error
    return { success: true }
  },

  // Remove item from cart by product ID
  async removeFromCartByProductId(productId) {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', user.id)
      .eq('product_id', productId)

    if (error) throw error
    return { success: true }
  },

  // Clear entire cart
  async clearCart() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', user.id)

    if (error) throw error
    return { success: true }
  },

  // Get cart count (total number of items)
  async getCartCount() {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return 0

    const { data, error } = await supabase
      .from('cart_items')
      .select('quantity')
      .eq('user_id', user.id)

    if (error) return 0
    
    // Sum up all quantities
    const totalCount = data?.reduce((sum, item) => sum + item.quantity, 0) || 0
    return totalCount
  },

  // Calculate total price
  calculateTotal(cartItems) {
    return cartItems.reduce((total, item) => {
      const price = item.products.discount > 0
        ? item.products.price * (1 - item.products.discount / 100)
        : item.products.price
      return total + (price * item.quantity)
    }, 0).toFixed(2)
  }
}