import 'react-native-url-polyfill/auto'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { createClient } from '@supabase/supabase-js'
import * as SecureStore from 'expo-secure-store'
import { Platform } from 'react-native'

// Replace these with your actual Supabase project values
const supabaseUrl = 'https://uodlsupwgorfscqfourt.supabase.co' // Replace with your URL from Supabase dashboard
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVvZGxzdXB3Z29yZnNjcWZvdXJ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMwOTMyNTgsImV4cCI6MjA2ODY2OTI1OH0.vS_3Wlyelw-wysI3zXAh_VDLk8zHWHEwwLX1K7wKyeo' // Replace with your anon key from Supabase dashboard

// Custom storage solution that uses SecureStore on mobile and AsyncStorage on web
const ExpoSecureStoreAdapter = {
  getItem: async (key) => {
    if (Platform.OS === 'web') {
      return AsyncStorage.getItem(key)
    }
    return SecureStore.getItemAsync(key)
  },
  setItem: async (key, value) => {
    if (Platform.OS === 'web') {
      return AsyncStorage.setItem(key, value)
    }
    return SecureStore.setItemAsync(key, value)
  },
  removeItem: async (key) => {
    if (Platform.OS === 'web') {
      return AsyncStorage.removeItem(key)
    }
    return SecureStore.deleteItemAsync(key)
  },
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: ExpoSecureStoreAdapter,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
})