import { supabase } from './supabase'

export const profileService = {
  // Get user profile
  async getProfile(userId) {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle()
      
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error)
        return null
      }
      
      return data
    } catch (error) {
      console.error('Error in getProfile:', error)
      return null
    }
  },

  // Update user profile
  async updateProfile(userId, updates) {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .update(updates)
        .eq('user_id', userId)
        .select()
        .single()
      
      if (error) throw error
      return data
    } catch (error) {
      console.error('Error in updateProfile:', error)
      throw error
    }
  },

  // Upload profile image
  async uploadProfileImage(userId, file) {
    try {
      // Create unique file name
      const fileName = `${userId}-${Date.now()}.jpg`
      const filePath = `${userId}/${fileName}`

      // For React Native, we need to handle the file differently
      let uploadData
      if (file.blob) {
        uploadData = file.blob
      } else if (file.uri) {
        // If we have a URI, fetch it as blob
        const response = await fetch(file.uri)
        uploadData = await response.blob()
      } else {
        uploadData = file
      }

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('profile-images')
        .upload(filePath, uploadData, {
          contentType: 'image/jpeg',
          cacheControl: '3600',
          upsert: false
        })

      if (uploadError) throw uploadError

      // Get public URL
      const { data } = supabase.storage
        .from('profile-images')
        .getPublicUrl(filePath)

      return data.publicUrl
    } catch (error) {
      console.error('Error uploading image:', error)
      throw error
    }
  },

  // Delete old profile image
  async deleteProfileImage(imageUrl) {
    if (!imageUrl || imageUrl.includes('ui-avatars.com')) return

    try {
      // Extract file path from URL
      const urlParts = imageUrl.split('/profile-images/')
      if (urlParts.length < 2) return

      const filePath = urlParts[1]
      
      const { error } = await supabase.storage
        .from('profile-images')
        .remove([filePath])

      if (error) console.error('Error deleting old image:', error)
    } catch (error) {
      console.error('Error in deleteProfileImage:', error)
    }
  }
}