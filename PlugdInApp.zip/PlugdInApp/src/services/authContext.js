import React, { createContext, useState, useEffect, useContext } from 'react'
import { supabase } from './supabase'
import * as WebBrowser from 'expo-web-browser'
import { makeRedirectUri } from 'expo-auth-session'
import { CommonActions } from '@react-navigation/native'

// Complete the WebBrowser result handling
WebBrowser.maybeCompleteAuthSession()

const AuthContext = createContext({})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)
  const [initializing, setInitializing] = useState(true)
  const [isDispensaryAdmin, setIsDispensaryAdmin] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [navigationRef, setNavigationRef] = useState(null)

  useEffect(() => {
    // Check if user is already logged in
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setUser(session?.user ?? null)
      checkDispensaryAdmin(session?.user)
      checkAdmin(session?.user)
      setLoading(false)
      
      // Set initializing to false after a delay to show splash screen
      setTimeout(() => {
        setInitializing(false)
      }, 2000)
    })

    // Listen for auth changes
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      setUser(session?.user ?? null)
      checkDispensaryAdmin(session?.user)
      checkAdmin(session?.user)
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [])

  // Check if user is dispensary admin
  const checkDispensaryAdmin = (user) => {
    if (user?.user_metadata?.role === 'dispensary_admin' || 
        user?.user_metadata?.username === 'DispensaryAdmin' ||
        (user?.email === 'gsingh.eric@gmail.com' && !user?.user_metadata?.isAdminLogin)) {
      setIsDispensaryAdmin(true)
    } else {
      setIsDispensaryAdmin(false)
    }
  }

  // Check if user is super admin
  const checkAdmin = (user) => {
    if (user?.email === 'gsingh.eric@gmail.com' && 
        user?.user_metadata?.isAdminLogin === true) {
      setIsAdmin(true)
      setIsDispensaryAdmin(false)
    } else {
      setIsAdmin(false)
    }
  }

  // Create user profile helper function
  const createUserProfile = async (userId, email, name = 'Guest', avatarUrl = null) => {
    try {
      const profileImage = avatarUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=FF69B4&color=fff`
      
      const { error } = await supabase
        .from('user_profiles')
        .upsert([{
          user_id: userId,
          email: email,
          name: name,
          profile_image: profileImage
        }], {
          onConflict: 'user_id'
        })
      
      if (error) {
        console.error('Error creating/updating profile:', error)
      }
    } catch (error) {
      console.error('Error in createUserProfile:', error)
    }
  }

  // Admin sign in
  const signInAsAdmin = async (username, password) => {
    try {
      // Check if credentials match
      if (username !== 'DispensaryAdmin' || password !== 'DispensaryPlugQOWPEI102') {
        return { 
          data: null, 
          error: { message: 'Access denied. Admin credentials required.' } 
        }
      }

      // Sign in with the admin email but mark it as admin login
      const result = await supabase.auth.signInWithPassword({ 
        email: 'gsingh.eric@gmail.com', 
        password: 'DispensaryPlugQOWPEI102' 
      })

      if (result.error) {
        return { 
          data: null, 
          error: { message: 'Access denied. Admin credentials required.' } 
        }
      }

      // Update user metadata to indicate admin login
      if (result.data?.user) {
        await supabase.auth.updateUser({
          data: { isAdminLogin: true, username: 'Admin' }
        })
      }

      return result
    } catch (error) {
      return { 
        data: null, 
        error: { message: 'Access denied. Admin credentials required.' } 
      }
    }
  }

  // Dispensary admin sign in
  const signInAsDispensaryAdmin = async (username, password) => {
    try {
      // Check if credentials match
      if (username !== 'DispensaryAdmin' || password !== 'DispensaryPlugQOWPEI102') {
        return { 
          data: null, 
          error: { message: 'Access denied. Dispensary credentials required.' } 
        }
      }

      // Sign in with the dispensary admin email
      const result = await supabase.auth.signInWithPassword({ 
        email: 'gsingh.eric@gmail.com', 
        password: 'DispensaryPlugQOWPEI102' 
      })

      if (result.error) {
        return { 
          data: null, 
          error: { message: 'Access denied. Dispensary credentials required.' } 
        }
      }

      // Update user metadata to indicate dispensary login
      if (result.data?.user) {
        await supabase.auth.updateUser({
          data: { isAdminLogin: false, username: 'DispensaryAdmin' }
        })
      }

      return result
    } catch (error) {
      return { 
        data: null, 
        error: { message: 'Access denied. Dispensary credentials required.' } 
      }
    }
  }

  const value = {
    user,
    session,
    loading,
    initializing,
    isDispensaryAdmin,
    isAdmin,
    navigationRef,
    setNavigationRef,
    signIn: async (email, password) => {
      try {
        const result = await supabase.auth.signInWithPassword({ email, password })
        
        // Check if profile exists, create if not
        if (result.data?.user && !result.error) {
          const { data: profile } = await supabase
            .from('user_profiles')
            .select('*')
            .eq('user_id', result.data.user.id)
            .maybeSingle()
          
          if (!profile) {
            // Get the name from user metadata or use email
            const name = result.data.user.user_metadata?.name || 
                        result.data.user.email.split('@')[0] || 
                        'Guest'
            
            await createUserProfile(
              result.data.user.id,
              result.data.user.email,
              name
            )
          }
        }
        
        return result
      } catch (error) {
        return { data: null, error }
      }
    },
    signInAsDispensaryAdmin,
    signInAsAdmin,
    signUp: async (email, password, name = 'Guest') => {
      try {
        // First, try to sign up the user
        const { data, error } = await supabase.auth.signUp({ 
          email, 
          password, 
          options: { 
            data: { name },
          } 
        })
        
        // Check for various error scenarios
        if (error) {
          return { data: null, error }
        }
        
        // Check if user already exists (Supabase returns a user object but doesn't send confirmation email)
        if (data?.user && data.user.identities && data.user.identities.length === 0) {
          return {
            data: null,
            error: {
              message: 'An account with this email already exists. Please sign in instead.'
            }
          }
        }
        
        // Check if the user was created but not confirmed yet
        if (data?.user && !data.session) {
          // This is a new user - email will be sent
          return { data, error: null }
        }
        
        return { data, error: null }
      } catch (error) {
        return { data: null, error }
      }
    },
    signOut: async () => {
      await supabase.auth.signOut()
      
      // Navigate to sign in screen after sign out
      if (navigationRef) {
        navigationRef.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{ name: 'Auth', params: { screen: 'SignIn' } }],
          })
        )
      }
    },
    resetPassword: (email) => 
      supabase.auth.resetPasswordForEmail(email, {
        redirectTo: 'com.yourapp.plugdin://reset-password',
      }),
    verifyOtp: (email, token) => supabase.auth.verifyOtp({ email, token, type: 'email' }),
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}