import React, { useRef, useEffect } from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { useAuth } from '../services/authContext'
import { View, ActivityIndicator } from 'react-native'
import { Ionicons } from '@expo/vector-icons'

// Import screens
import SplashScreen from '../screens/SplashScreen'
import SignInScreen from '../screens/SignInScreen'
import SignUpScreen from '../screens/SignUpScreen'
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen'
import VerifyEmailScreen from '../screens/VerifyEmailScreen'
import ResetPasswordVerifyScreen from '../screens/ResetPasswordVerifyScreen'
import SetNewPasswordScreen from '../screens/SetNewPasswordScreen'
import HomeScreen from '../screens/HomeScreen'
import AllProductsScreen from '../screens/AllProductsScreen'
import ProductDetailScreen from '../screens/ProductDetailScreen'
import CartScreen from '../screens/CartScreen'
import CheckoutScreen from '../screens/CheckoutScreen'
import SettingsScreen from '../screens/SettingsScreen'
import OrderTrackingScreen from '../screens/OrderTrackingScreen'
import NotificationsScreen from '../screens/NotificationsScreen'
import TermsAndConditionsScreen from '../screens/TermsAndConditionsScreen'
import HelpCenterScreen from '../screens/HelpCenterScreen'

// Import dispensary screens
import DispensaryLoginScreen from '../screens/DispensaryLoginScreen'
import DispensaryNavigator from './DispensaryNavigator'

// Import admin screens
import AdminSignInScreen from '../screens/AdminSignInScreen'
import AdminNavigator from './AdminNavigator'

const Stack = createStackNavigator()
const Tab = createBottomTabNavigator()

// Cart stack
const CartStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="CartMain" component={CartScreen} />
      <Stack.Screen name="Checkout" component={CheckoutScreen} />
    </Stack.Navigator>
  )
}

// Main app tabs (for all users - signed in or not)
const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#000',
          borderTopWidth: 0,
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: '#FF69B4',
        tabBarInactiveTintColor: '#999',
        headerShown: false,
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeStack}
        options={{
          tabBarLabel: 'HOME',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home-outline" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Cart"
        component={CartStack}
        options={{
          tabBarLabel: 'CART',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="cart-outline" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Orders"
        component={OrderTrackingScreen}
        options={{
          tabBarLabel: 'ORDERS',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="receipt-outline" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          tabBarLabel: 'SETTINGS',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="settings-outline" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  )
}

// Home stack (for navigation within home tab)
const HomeStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="AllProducts" component={AllProductsScreen} />
      <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
    </Stack.Navigator>
  )
}

// Auth stack for sign in/up
const AuthStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SignIn" component={SignInScreen} />
      <Stack.Screen name="SignUp" component={SignUpScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
      <Stack.Screen name="VerifyEmail" component={VerifyEmailScreen} />
      <Stack.Screen name="ResetPasswordVerify" component={ResetPasswordVerifyScreen} />
      <Stack.Screen name="SetNewPassword" component={SetNewPasswordScreen} />
      <Stack.Screen name="DispensaryLogin" component={DispensaryLoginScreen} />
      <Stack.Screen name="AdminSignIn" component={AdminSignInScreen} />
    </Stack.Navigator>
  )
}

const AppNavigator = () => {
  const { user, loading, isDispensaryAdmin, isAdmin, initializing, setNavigationRef } = useAuth()
  const navigationRef = useRef(null)

  useEffect(() => {
    if (navigationRef.current) {
      setNavigationRef(navigationRef.current)
    }
  }, [navigationRef.current])

  if (initializing) {
    return <SplashScreen />
  }

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#FF69B4" />
      </View>
    )
  }

  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {/* Check if user is admin or dispensary admin */}
        {user && isDispensaryAdmin ? (
          <Stack.Screen name="DispensaryMain" component={DispensaryNavigator} />
        ) : user && isAdmin ? (
          <Stack.Screen name="AdminMain" component={AdminNavigator} />
        ) : (
          // All other users (signed in or not) get main app
          <>
            <Stack.Screen name="Main" component={MainTabs} />
            <Stack.Screen name="Auth" component={AuthStack} />
            <Stack.Screen name="Notifications" component={NotificationsScreen} />
            <Stack.Screen name="TermsAndConditions" component={TermsAndConditionsScreen} />
            <Stack.Screen name="HelpCenter" component={HelpCenterScreen} />
            <Stack.Screen name="SetNewPassword" component={SetNewPasswordScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  )
}

export default AppNavigator