import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Modal,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { supabase } from '../services/supabase'
import * as Notifications from 'expo-notifications'

// Function to send push notification
const sendPushNotification = async (title, body) => {
  try {
    // Get all push tokens from your database
    // You'll need to create a table to store push tokens
    const { data: tokens, error } = await supabase
      .from('push_tokens')
      .select('token')
      .eq('is_active', true)

    if (error) {
      console.error('Error fetching tokens:', error)
      return
    }

    // Send notification to each token
    const messages = tokens.map(({ token }) => ({
      to: token,
      sound: 'default',
      title: title,
      body: body,
      data: { type: 'notification' },
      badge: 1,
    }))

    // Send notifications in batches
    const chunks = []
    for (let i = 0; i < messages.length; i += 100) {
      chunks.push(messages.slice(i, i + 100))
    }

    for (const chunk of chunks) {
      await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Accept-encoding': 'gzip, deflate',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(chunk),
      })
    }
  } catch (error) {
    console.error('Error sending push notifications:', error)
  }
}

// Notification/Coupon Modal Component
const ItemModal = ({ visible, onClose, item, onSave, isNew, type }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: type === 'coupon' ? '' : 'general',
    icon: type === 'coupon' ? '' : 'notifications-outline',
    color: '#FF69B4',
    code: '', // for coupons
    discount: '', // for coupons
    is_active: true,
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (visible) {
      if (item && !isNew) {
        setFormData({
          title: item.title || '',
          description: item.description || '',
          type: item.type || 'general',
          icon: item.icon || 'notifications-outline',
          color: item.color || '#FF69B4',
          code: item.code || '',
          discount: item.discount?.toString() || '',
          is_active: item.is_active ?? true,
        })
      } else {
        setFormData({
          title: '',
          description: '',
          type: type === 'coupon' ? '' : 'general',
          icon: type === 'coupon' ? '' : 'notifications-outline',
          color: '#FF69B4',
          code: '',
          discount: '',
          is_active: true,
        })
      }
    }
  }, [visible, item, isNew, type])

  const handleSave = async () => {
    // Different validation for coupons vs notifications
    if (type === 'coupon') {
      if (!formData.code || !formData.description || !formData.discount) {
        Alert.alert('Error', 'Please fill in all required fields')
        return
      }
    } else {
      if (!formData.title || !formData.description) {
        Alert.alert('Error', 'Please fill in all required fields')
        return
      }
    }

    setLoading(true)
    try {
      const data = type === 'coupon' 
        ? {
            code: formData.code.toUpperCase(),
            description: formData.description,
            discount: parseFloat(formData.discount) / 100,
            is_active: formData.is_active,
          }
        : {
            title: formData.title,
            description: formData.description,
            type: formData.type,
            icon: formData.icon,
            color: formData.color,
            is_active: formData.is_active,
          }

      await onSave(data)
      
      // Send push notification if it's a new notification
      if (type === 'notification' && isNew && formData.is_active) {
        await sendPushNotification(formData.title, formData.description)
      }
      
      onClose()
    } catch (error) {
      console.error('Modal save error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.modalKeyboardView}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {isNew ? `Add New ${type === 'coupon' ? 'Coupon' : 'Notification'}` : `Edit ${type === 'coupon' ? 'Coupon' : 'Notification'}`}
              </Text>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={24} color="#000" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {type === 'coupon' ? (
                <>
                  <Text style={styles.inputLabel}>Coupon Code *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.code}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, code: text }))}
                    placeholder="e.g. SAVE20"
                    autoCapitalize="characters"
                  />

                  <Text style={styles.inputLabel}>Description *</Text>
                  <TextInput
                    style={[styles.input, styles.textArea]}
                    value={formData.description}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, description: text }))}
                    placeholder="e.g. Save 20% on your next order"
                    multiline
                    numberOfLines={3}
                  />

                  <Text style={styles.inputLabel}>Discount Percentage *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.discount}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, discount: text }))}
                    placeholder="20"
                    keyboardType="numeric"
                  />
                </>
              ) : (
                <>
                  <Text style={styles.inputLabel}>Title *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.title}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, title: text }))}
                    placeholder="e.g. New Arrival"
                  />

                  <Text style={styles.inputLabel}>Description *</Text>
                  <TextInput
                    style={[styles.input, styles.textArea]}
                    value={formData.description}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, description: text }))}
                    placeholder="Notification description..."
                    multiline
                    numberOfLines={3}
                  />

                  <Text style={styles.inputLabel}>Type</Text>
                  <View style={styles.typeContainer}>
                    {['general', 'promo', 'update', 'alert'].map((t) => (
                      <TouchableOpacity
                        key={t}
                        style={[
                          styles.typeButton,
                          formData.type === t && styles.selectedTypeButton
                        ]}
                        onPress={() => setFormData(prev => ({ ...prev, type: t }))}
                      >
                        <Text style={[
                          styles.typeButtonText,
                          formData.type === t && styles.selectedTypeButtonText
                        ]}>
                          {t.toUpperCase()}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </>
              )}

              <View style={styles.activeContainer}>
                <Text style={styles.inputLabel}>Active</Text>
                <TouchableOpacity
                  style={[
                    styles.activeToggle,
                    formData.is_active && styles.activeToggleOn
                  ]}
                  onPress={() => setFormData(prev => ({ ...prev, is_active: !prev.is_active }))}
                >
                  <Text style={[
                    styles.activeToggleText,
                    formData.is_active && styles.activeToggleTextOn
                  ]}>
                    {formData.is_active ? 'YES' : 'NO'}
                  </Text>
                </TouchableOpacity>
              </View>

              <TouchableOpacity 
                style={[styles.saveButton, loading && styles.disabledButton]}
                onPress={handleSave}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.saveButtonText}>
                    {isNew ? `Add ${type === 'coupon' ? 'Coupon' : 'Notification'}` : 'Save Changes'}
                  </Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={onClose}
                disabled={loading}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  )
}

const NotificationManagementScreen = ({ route }) => {
  const navigation = useNavigation()
  const [selectedTab, setSelectedTab] = useState(route.params?.initialTab || 'coupons')
  const [coupons, setCoupons] = useState([])
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState(null)
  const [isNewItem, setIsNewItem] = useState(false)

  useEffect(() => {
    fetchData()
    
    // Subscribe to real-time changes
    const notificationsSubscription = supabase
      .channel('notifications_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, () => {
        fetchNotifications()
      })
      .subscribe()

    const couponsSubscription = supabase
      .channel('coupons_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'coupon_codes' }, () => {
        fetchCoupons()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(notificationsSubscription)
      supabase.removeChannel(couponsSubscription)
    }
  }, [])

  // Handle route params for initial tab
  useEffect(() => {
    if (route.params?.initialTab) {
      setSelectedTab(route.params.initialTab)
      // If we navigated here to add something, open the modal
      if (route.params?.openAdd) {
        handleAdd()
      }
    }
  }, [route.params])

  const fetchData = async () => {
    await Promise.all([fetchCoupons(), fetchNotifications()])
    setLoading(false)
    setRefreshing(false)
  }

  const fetchCoupons = async () => {
    try {
      const { data, error } = await supabase
        .from('coupon_codes')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setCoupons(data || [])
    } catch (error) {
      console.error('Error fetching coupons:', error)
    }
  }

  const fetchNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setNotifications(data || [])
    } catch (error) {
      console.error('Error fetching notifications:', error)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchData()
  }

  const handleAdd = () => {
    setSelectedItem(null)
    setIsNewItem(true)
    setShowModal(true)
  }

  const handleEdit = (item) => {
    setSelectedItem(item)
    setIsNewItem(false)
    setShowModal(true)
  }

  const handleDelete = async (id, title) => {
    Alert.alert(
      'Delete',
      `Are you sure you want to delete "${title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const table = selectedTab === 'coupons' ? 'coupon_codes' : 'notifications'
              const { error } = await supabase
                .from(table)
                .delete()
                .eq('id', id)

              if (error) throw error
              
              Alert.alert('Success', `${selectedTab === 'coupons' ? 'Coupon' : 'Notification'} deleted successfully`)
              fetchData()
            } catch (error) {
              console.error('Error deleting:', error)
              Alert.alert('Error', 'Failed to delete')
            }
          }
        }
      ]
    )
  }

  const handleSave = async (data) => {
    try {
      const table = selectedTab === 'coupons' ? 'coupon_codes' : 'notifications'
      
      if (isNewItem) {
        const { error } = await supabase
          .from(table)
          .insert([data])

        if (error) throw error
        Alert.alert('Success', `${selectedTab === 'coupons' ? 'Coupon' : 'Notification'} added successfully`)
      } else {
        const { error } = await supabase
          .from(table)
          .update(data)
          .eq('id', selectedItem.id)

        if (error) throw error
        Alert.alert('Success', `${selectedTab === 'coupons' ? 'Coupon' : 'Notification'} updated successfully`)
      }
      
      fetchData()
    } catch (error) {
      console.error('Error saving:', error)
      Alert.alert('Error', 'Failed to save')
    }
  }

  const renderItem = (item) => {
    const isCoupon = selectedTab === 'coupons'
    
    return (
      <View key={item.id} style={styles.itemCard}>
        <View style={styles.itemHeader}>
          <View style={styles.itemInfo}>
            <Text style={styles.itemTitle}>
              {isCoupon ? item.code : item.title}
            </Text>
            <Text style={styles.itemDescription}>
              {item.description}
            </Text>
            {isCoupon && (
              <Text style={styles.itemDiscount}>
                {(item.discount * 100).toFixed(0)}% OFF
              </Text>
            )}
          </View>
          <View style={[styles.statusBadge, { backgroundColor: item.is_active ? '#4CAF50' : '#F44336' }]}>
            <Text style={styles.statusText}>
              {item.is_active ? 'ACTIVE' : 'INACTIVE'}
            </Text>
          </View>
        </View>
        
        <View style={styles.itemActions}>
          <TouchableOpacity onPress={() => handleEdit(item)}>
            <Ionicons name="create-outline" size={24} color="#FF69B4" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDelete(item.id, isCoupon ? item.code : item.title)}>
            <Ionicons name="trash-outline" size={24} color="#FF0000" />
          </TouchableOpacity>
        </View>
      </View>
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>DISCOUNTS</Text>
          <TouchableOpacity style={styles.addButton} onPress={handleAdd}>
            <Text style={styles.addButtonText}>ADD {selectedTab === 'coupons' ? 'COUPON' : 'NOTIFICATION'}</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  const currentItems = selectedTab === 'coupons' ? coupons : notifications

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>MANAGEMENT</Text>
        <TouchableOpacity style={styles.addButton} onPress={handleAdd}>
          <Text style={styles.addButtonText}>ADD {selectedTab === 'coupons' ? 'COUPON' : 'NOTIFICATION'}</Text>
        </TouchableOpacity>
      </View>

      {/* Tab Selector */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'coupons' && styles.activeTab]}
          onPress={() => setSelectedTab('coupons')}
        >
          <Text style={[styles.tabText, selectedTab === 'coupons' && styles.activeTabText]}>
            COUPONS
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'notifications' && styles.activeTab]}
          onPress={() => setSelectedTab('notifications')}
        >
          <Text style={[styles.tabText, selectedTab === 'notifications' && styles.activeTabText]}>
            NOTIFICATIONS
          </Text>
        </TouchableOpacity>
      </View>

      {/* List */}
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
        contentContainerStyle={styles.scrollContent}
      >
        {currentItems.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons 
              name={selectedTab === 'coupons' ? 'pricetag-outline' : 'notifications-outline'} 
              size={60} 
              color="#CCC" 
            />
            <Text style={styles.emptyText}>
              No {selectedTab} found
            </Text>
            <TouchableOpacity style={styles.emptyAddButton} onPress={handleAdd}>
              <Text style={styles.emptyAddButtonText}>
                Add Your First {selectedTab === 'coupons' ? 'Coupon' : 'Notification'}
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          currentItems.map(renderItem)
        )}
      </ScrollView>

      {/* Modal */}
      <ItemModal
        visible={showModal}
        onClose={() => setShowModal(false)}
        item={selectedItem}
        onSave={handleSave}
        isNew={isNewItem}
        type={selectedTab === 'coupons' ? 'coupon' : 'notification'}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  addButton: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 20,
    marginHorizontal: 5,
  },
  activeTab: {
    backgroundColor: '#FF69B4',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  activeTabText: {
    color: '#FFF',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  itemCard: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  itemInfo: {
    flex: 1,
    marginRight: 10,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 5,
  },
  itemDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  itemDiscount: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4CAF50',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FFF',
  },
  itemActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 15,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 100,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
    marginBottom: 30,
  },
  emptyAddButton: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  emptyAddButtonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalKeyboardView: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 20,
    paddingHorizontal: 20,
    paddingBottom: 40,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
    marginTop: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#EEE',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 14,
    color: '#333',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  typeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: 5,
  },
  typeButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 15,
    backgroundColor: '#F5F5F5',
    borderWidth: 1,
    borderColor: '#EEE',
  },
  selectedTypeButton: {
    backgroundColor: '#FF69B4',
    borderColor: '#FF69B4',
  },
  typeButtonText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  selectedTypeButtonText: {
    color: '#FFF',
  },
  activeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  activeToggle: {
    paddingHorizontal: 30,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    borderWidth: 1,
    borderColor: '#EEE',
  },
  activeToggleOn: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  activeToggleText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  activeToggleTextOn: {
    color: '#FFF',
  },
  saveButton: {
    backgroundColor: '#FF69B4',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 30,
  },
  disabledButton: {
    opacity: 0.6,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
  cancelButton: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  cancelButtonText: {
    fontSize: 16,
    color: '#666',
  },
})

export default NotificationManagementScreen