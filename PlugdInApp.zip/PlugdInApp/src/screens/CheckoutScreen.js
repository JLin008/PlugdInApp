import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { cartService } from '../services/cartService'
import { orderService } from '../services/orderService'
import { supabase } from '../services/supabase'
import { useAuth } from '../services/authContext'
import { useCart } from '../services/cartContext'
import * as Location from 'expo-location'

// Minimum Order Modal Component
const MinimumOrderModal = ({ visible, onClose, currentTotal, minimumAmount }) => {
  const needed = minimumAmount - currentTotal
  
  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="fade"
    >
      <View style={styles.minimumModalContainer}>
        <View style={styles.minimumModalContent}>
          <Ionicons name="alert-circle" size={60} color="#FF69B4" />
          
          <Text style={styles.minimumModalTitle}>Minimum Order Required</Text>
          
          <Text style={styles.minimumModalText}>
            The minimum order amount is ${minimumAmount.toFixed(2)}
          </Text>
          
          <Text style={styles.minimumModalSubtext}>
            Your current order total is ${currentTotal.toFixed(2)}
          </Text>
          
          <Text style={styles.minimumModalNeeded}>
            Add ${needed.toFixed(2)} more to checkout
          </Text>
          
          <TouchableOpacity
            style={styles.minimumModalButton}
            onPress={onClose}
          >
            <Text style={styles.minimumModalButtonText}>Continue Shopping</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  )
}

// Address Modal Component with Location Feature
const AddressModal = ({ visible, onClose, address, setAddress }) => {
  const [loadingLocation, setLoadingLocation] = useState(false)

  const handleUseCurrentLocation = async () => {
    setLoadingLocation(true)
    try {
      // Request permission
      const { status } = await Location.requestForegroundPermissionsAsync()
      
      if (status !== 'granted') {
        Alert.alert(
          'Permission Denied',
          'Please enable location services to use this feature.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Open Settings', onPress: () => Location.requestForegroundPermissionsAsync() }
          ]
        )
        setLoadingLocation(false)
        return
      }

      // Get current location with high accuracy
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      })

      // Reverse geocode to get address
      const addressResults = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      })

      if (addressResults.length > 0) {
        const result = addressResults[0]
        
        // Format the address components
        const streetNumber = result.streetNumber || ''
        const street = result.street || result.name || ''
        const addressLine1 = `${streetNumber} ${street}`.trim()

        // Update address state
        setAddress({
          line1: addressLine1 || 'Address not found',
          line2: '',
          city: result.city || '',
          state: result.region || result.subregion || '',
          zipCode: result.postalCode || '',
        })

        // Show success message
        Alert.alert('Success', 'Address filled from your current location')
      } else {
        Alert.alert('Error', 'Could not find address for your location')
      }
    } catch (error) {
      console.error('Location error:', error)
      
      // Provide specific error messages
      if (error.code === 'E_LOCATION_SERVICES_DISABLED') {
        Alert.alert(
          'Location Services Disabled',
          'Please enable location services in your device settings.'
        )
      } else if (error.code === 'E_LOCATION_TIMEOUT') {
        Alert.alert(
          'Location Timeout',
          'Unable to get your location. Please try again.'
        )
      } else {
        Alert.alert(
          'Location Error',
          'Unable to get your current location. Please enter address manually.'
        )
      }
    } finally {
      setLoadingLocation(false)
    }
  }

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
    >
      <View style={styles.modalContainer}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.modalKeyboardView}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Delivery Address</Text>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={24} color="#000" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Use Current Location Button */}
              <TouchableOpacity 
                style={styles.locationButton}
                onPress={handleUseCurrentLocation}
                disabled={loadingLocation}
              >
                {loadingLocation ? (
                  <ActivityIndicator size="small" color="#FFF" />
                ) : (
                  <>
                    <Ionicons name="location" size={20} color="#FFF" />
                    <Text style={styles.locationButtonText}>Use Current Location</Text>
                  </>
                )}
              </TouchableOpacity>

              <View style={styles.divider}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>OR ENTER MANUALLY</Text>
                <View style={styles.dividerLine} />
              </View>

              <Text style={styles.inputLabel}>Address Line 1 *</Text>
              <TextInput
                style={styles.input}
                value={address.line1}
                onChangeText={(text) => setAddress(prev => ({...prev, line1: text}))}
                placeholder="123 Main Street"
              />

              <Text style={styles.inputLabel}>Address Line 2</Text>
              <TextInput
                style={styles.input}
                value={address.line2}
                onChangeText={(text) => setAddress(prev => ({...prev, line2: text}))}
                placeholder="Apt, Suite, etc. (optional)"
              />

              <Text style={styles.inputLabel}>City *</Text>
              <TextInput
                style={styles.input}
                value={address.city}
                onChangeText={(text) => setAddress(prev => ({...prev, city: text}))}
                placeholder="New York"
              />

              <Text style={styles.inputLabel}>State (Initials) *</Text>
              <TextInput
                style={styles.input}
                value={address.state}
                onChangeText={(text) => setAddress(prev => ({...prev, state: text}))}
                placeholder="NY"
                maxLength={2}
                autoCapitalize="characters"
              />

              <Text style={styles.inputLabel}>Zip Code *</Text>
              <TextInput
                style={styles.input}
                value={address.zipCode}
                onChangeText={(text) => setAddress(prev => ({...prev, zipCode: text}))}
                placeholder="10001"
                keyboardType="numeric"
                maxLength={5}
              />

              <TouchableOpacity 
                style={styles.saveButton}
                onPress={() => {
                  if (!address.line1 || !address.city || !address.state || !address.zipCode) {
                    Alert.alert('Error', 'Please fill in all required fields')
                    return
                  }
                  onClose()
                }}
              >
                <Text style={styles.saveButtonText}>Save Address</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  )
}

const CheckoutScreen = () => {
  const navigation = useNavigation()
  const { user } = useAuth()
  const { profile: contextProfile, refreshCartCount } = useCart()
  const [cartItems, setCartItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [placing, setPlacing] = useState(false)
  const [couponCode, setCouponCode] = useState('')
  const [appliedCoupon, setAppliedCoupon] = useState(null)
  const [showAddressModal, setShowAddressModal] = useState(false)
  const [showMinimumModal, setShowMinimumModal] = useState(false)
  const [selectedPayment, setSelectedPayment] = useState('4532')
  
  // Address state
  const [address, setAddress] = useState({
    line1: '',
    line2: '',
    city: '',
    state: '',
    zipCode: '',
  })

  const DELIVERY_FEE = 4.99
  const TAX_RATE = 0.10
  const MINIMUM_ORDER = 50.00

  useEffect(() => {
    fetchCartItems()
  }, [])

  const fetchCartItems = async () => {
    try {
      const items = await cartService.getCartItems()
      setCartItems(items)
    } catch (error) {
      Alert.alert('Error', 'Failed to load cart items')
    } finally {
      setLoading(false)
    }
  }

  // Calculate totals
  const itemTotal = cartItems.reduce((total, item) => {
    const price = item.products.discount > 0
      ? item.products.price * (1 - item.products.discount / 100)
      : item.products.price
    return total + (price * item.quantity)
  }, 0)

  const tax = itemTotal * TAX_RATE
  const discountAmount = appliedCoupon ? itemTotal * appliedCoupon.discount : 0
  const total = itemTotal + DELIVERY_FEE + tax - discountAmount

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) {
      Alert.alert('Error', 'Please enter a coupon code')
      return
    }

    // Check if a coupon is already applied
    if (appliedCoupon) {
      Alert.alert('Failed', 'You already redeemed a coupon')
      return
    }

    try {
      // First check if user has already used this coupon (only if signed in)
      if (user) {
        const { data: usedCoupon, error: usedError } = await supabase
          .from('used_coupons')
          .select('*')
          .eq('user_id', user.id)
          .eq('coupon_code', couponCode.toUpperCase())
          .maybeSingle()

        if (usedCoupon) {
          Alert.alert('Coupon Already Used', 'You have already used this coupon code.')
          setCouponCode('')
          return
        }
      }

      // Check if coupon exists and is active
      const { data, error } = await supabase
        .from('coupon_codes')
        .select('*')
        .eq('code', couponCode.toUpperCase())
        .eq('is_active', true)
        .single()

      if (error || !data) {
        Alert.alert('Invalid Code', 'Invalid coupon code')
        setCouponCode('')
        return
      }

      setAppliedCoupon(data)
      Alert.alert('Success', `${(data.discount * 100).toFixed(0)}% discount applied!`)
    } catch (error) {
      Alert.alert('Error', 'Failed to apply coupon')
    }
  }

  const handlePlaceOrder = async () => {
    // Check minimum order amount
    if (itemTotal < MINIMUM_ORDER) {
      setShowMinimumModal(true)
      return
    }

    if (!address.line1 || !address.city || !address.state || !address.zipCode) {
      Alert.alert('Missing Information', 'Please add a delivery address')
      return
    }

    setPlacing(true)

    try {
      // First, validate stock for all items
      for (const item of cartItems) {
        const { data: productData, error: stockError } = await supabase
          .from('products')
          .select('stock, name')
          .eq('id', item.product_id)
          .single()

        if (stockError) {
          console.error('Stock check error:', stockError)
          Alert.alert('Error', 'Failed to check product availability')
          setPlacing(false)
          return
        }

        if (productData.stock < item.quantity) {
          Alert.alert(
            'Insufficient Stock',
            `Sorry, we only have ${productData.stock} units of ${productData.name} in stock. You are trying to order ${item.quantity} units.`
          )
          setPlacing(false)
          return
        }
      }

      // Prepare order data
      const orderData = {
        customerName: user ? (contextProfile?.name || user?.email?.split('@')[0] || 'Guest') : 'GUEST',
        customerEmail: user?.email || 'guest@plugdin.com',
        deliveryAddress: formatAddress(),
        items: cartItems.map(item => ({
          productId: item.product_id,
          productName: item.products.name,
          productBrand: item.products.brand,
          price: item.products.discount > 0
            ? item.products.price * (1 - item.products.discount / 100)
            : item.products.price,
          quantity: item.quantity,
          imageUrl: item.products.image_url
        })),
        subtotal: itemTotal,
        deliveryFee: DELIVERY_FEE,
        tax: tax,
        discountAmount: discountAmount,
        total: total
      }

      // Create the order
      const order = await orderService.createOrder(orderData)

      // Now deduct stock for each product using the database function
      console.log('Starting stock deduction for', cartItems.length, 'items')
      
      for (const item of cartItems) {
        try {
          console.log(`Deducting ${item.quantity} from product ${item.product_id} (${item.products.name})`)
          
          // Call the database function to update stock
          const { error } = await supabase
            .rpc('update_product_stock', {
              product_id: item.product_id,
              quantity_change: -item.quantity // negative to deduct
            })

          if (error) {
            console.error(`Error updating stock for product ${item.product_id}:`, error)
          } else {
            console.log(`Successfully updated stock for ${item.products.name}`)
          }
        } catch (err) {
          console.error('Error in stock deduction:', err)
        }
      }

      // Track coupon usage if one was applied and user is signed in
      if (appliedCoupon && user) {
        try {
          const { error: couponError } = await supabase
            .from('used_coupons')
            .insert([{
              user_id: user.id,
              coupon_code: appliedCoupon.code,
              order_id: order.id
            }])

          if (couponError) {
            console.error('Error tracking coupon usage:', couponError)
          }
        } catch (err) {
          console.error('Coupon tracking error:', err)
        }
      }

      // Clear the cart
      await cartService.clearCart()
      
      // Refresh cart count
      await refreshCartCount()

      // Show success message
      Alert.alert(
        'Order Placed!', 
        `Your order ${order.order_number} has been placed successfully.`,
        [
          {
            text: 'OK',
            onPress: () => {
              // Navigate back to home
              navigation.navigate('HomeTab')
            }
          }
        ]
      )
    } catch (error) {
      console.error('Error placing order:', error)
      Alert.alert('Error', 'Failed to place order. Please try again.')
    } finally {
      setPlacing(false)
    }
  }

  const formatAddress = () => {
    if (!address.line1) return 'Add delivery address'
    return `${address.line1}${address.line2 ? ', ' + address.line2 : ''}, ${address.city}, ${address.state} ${address.zipCode}`
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Checkout</Text>
          <View style={{ width: 24 }} />
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Checkout</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Delivery Address */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>DELIVERY ADDRESS</Text>
          <TouchableOpacity 
            style={styles.addressContainer}
            onPress={() => setShowAddressModal(true)}
          >
            <View style={styles.addressContent}>
              <Ionicons name="location-outline" size={20} color="#FF69B4" />
              <Text style={styles.addressText} numberOfLines={2}>
                {formatAddress()}
              </Text>
            </View>
            <TouchableOpacity 
              style={styles.changeButton}
              onPress={() => setShowAddressModal(true)}
            >
              <Text style={styles.changeButtonText}>Change Address</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        </View>

        {/* Payment Method */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>PAYMENT METHOD</Text>
          
          <TouchableOpacity 
            style={[styles.paymentOption, selectedPayment === '4532' && styles.selectedPayment]}
            onPress={() => {
              setSelectedPayment('4532')
              Alert.alert('Coming Soon', 'Payment processing not implemented yet')
            }}
          >
            <View style={styles.paymentContent}>
              <Ionicons name="card-outline" size={20} color="#000" />
              <Text style={styles.paymentText}>•••• •••• •••• 4532</Text>
            </View>
            {selectedPayment === '4532' && (
              <Ionicons name="checkmark-circle" size={20} color="#FF69B4" />
            )}
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.addPaymentButton}
            onPress={() => Alert.alert('Coming Soon', 'Feature not added yet')}
          >
            <Ionicons name="add-circle-outline" size={20} color="#FF69B4" />
            <Text style={styles.addPaymentText}>Add New Card</Text>
          </TouchableOpacity>
        </View>

        {/* Order Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ORDER SUMMARY</Text>
          
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>{cartItems.length} items</Text>
            <Text style={styles.summaryValue}>${itemTotal.toFixed(2)}</Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Delivery Fee</Text>
            <Text style={styles.summaryValue}>${DELIVERY_FEE.toFixed(2)}</Text>
          </View>

          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Tax</Text>
            <Text style={styles.summaryValue}>${tax.toFixed(2)}</Text>
          </View>

          {appliedCoupon && (
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: '#4CAF50' }]}>
                Discount ({appliedCoupon.code})
              </Text>
              <Text style={[styles.summaryValue, { color: '#4CAF50' }]}>
                -${discountAmount.toFixed(2)}
              </Text>
            </View>
          )}

          <View style={[styles.summaryRow, styles.totalRow]}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>${total.toFixed(2)}</Text>
          </View>

          {itemTotal < MINIMUM_ORDER && (
            <View style={styles.minimumWarning}>
              <Ionicons name="information-circle" size={16} color="#FF9800" />
              <Text style={styles.minimumWarningText}>
                Minimum order amount is ${MINIMUM_ORDER.toFixed(2)}
              </Text>
            </View>
          )}
        </View>

        {/* Coupon Code */}
        <View style={styles.section}>
          {appliedCoupon ? (
            <View style={styles.appliedCouponContainer}>
              <View style={styles.appliedCouponContent}>
                <Ionicons name="checkmark-circle" size={20} color="#4CAF50" />
                <Text style={styles.appliedCouponText}>
                  Coupon {appliedCoupon.code} applied - {(appliedCoupon.discount * 100).toFixed(0)}% off
                </Text>
              </View>
              <TouchableOpacity 
                onPress={() => {
                  setAppliedCoupon(null)
                  setCouponCode('')
                }}
              >
                <Text style={styles.removeCouponText}>Remove</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.couponContainer}>
              <TextInput
                style={styles.couponInput}
                placeholder="Enter Promo Code"
                value={couponCode}
                onChangeText={setCouponCode}
                autoCapitalize="characters"
              />
              <TouchableOpacity 
                style={styles.applyButton}
                onPress={handleApplyCoupon}
              >
                <Text style={styles.applyButtonText}>APPLY</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Total Price */}
        <View style={styles.totalSection}>
          <Text style={styles.totalPriceLabel}>TOTAL PRICE</Text>
          <Text style={styles.totalPrice}>${total.toFixed(2)}</Text>
        </View>
      </ScrollView>

      {/* Place Order Button */}
      <View style={styles.bottomSection}>
        <TouchableOpacity 
          style={[styles.placeOrderButton, placing && styles.placingButton]}
          onPress={handlePlaceOrder}
          disabled={placing}
        >
          {placing ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text style={styles.placeOrderText}>PLACE ORDER</Text>
          )}
        </TouchableOpacity>
      </View>

      <AddressModal 
        visible={showAddressModal}
        onClose={() => setShowAddressModal(false)}
        address={address}
        setAddress={setAddress}
      />

      <MinimumOrderModal
        visible={showMinimumModal}
        onClose={() => {
          setShowMinimumModal(false)
          navigation.goBack()
        }}
        currentTotal={itemTotal}
        minimumAmount={MINIMUM_ORDER}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  section: {
    backgroundColor: '#FFF',
    padding: 20,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 15,
  },
  addressContainer: {
    borderWidth: 1,
    borderColor: '#EEE',
    borderRadius: 10,
    padding: 15,
  },
  addressContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  addressText: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
  changeButton: {
    alignSelf: 'flex-end',
  },
  changeButtonText: {
    color: '#FF69B4',
    fontSize: 14,
    fontWeight: '600',
  },
  paymentOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderWidth: 1,
    borderColor: '#EEE',
    borderRadius: 10,
    marginBottom: 10,
  },
  selectedPayment: {
    borderColor: '#FF69B4',
    backgroundColor: '#FFF5F5',
  },
  paymentContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  paymentText: {
    marginLeft: 10,
    fontSize: 14,
    color: '#333',
  },
  addPaymentButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
  },
  addPaymentText: {
    marginLeft: 10,
    color: '#FF69B4',
    fontSize: 14,
    fontWeight: '600',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#666',
  },
  summaryValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: '#EEE',
    paddingTop: 10,
    marginTop: 5,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  minimumWarning: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF3E0',
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
  },
  minimumWarningText: {
    fontSize: 12,
    color: '#FF9800',
    marginLeft: 8,
    fontWeight: '600',
  },
  couponContainer: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#EEE',
    borderRadius: 10,
    overflow: 'hidden',
  },
  couponInput: {
    flex: 1,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 14,
  },
  applyButton: {
    backgroundColor: '#000',
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  applyButtonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  appliedCouponContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    padding: 15,
    borderRadius: 10,
  },
  appliedCouponContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  appliedCouponText: {
    marginLeft: 10,
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '600',
  },
  removeCouponText: {
    color: '#FF0000',
    fontSize: 14,
    fontWeight: '600',
  },
  totalSection: {
    backgroundColor: '#FFF',
    padding: 20,
    marginBottom: 10,
    alignItems: 'center',
  },
  totalPriceLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  totalPrice: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000',
  },
  bottomSection: {
    backgroundColor: '#FFF',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#EEE',
  },
  placeOrderButton: {
    backgroundColor: '#000',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
  },
  placingButton: {
    backgroundColor: '#666',
  },
  placeOrderText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalKeyboardView: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 20,
    paddingHorizontal: 20,
    paddingBottom: 40,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  // New styles for location feature
  locationButton: {
    backgroundColor: '#FF69B4',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    borderRadius: 25,
    marginBottom: 20,
    gap: 10,
  },
  locationButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#EEE',
  },
  dividerText: {
    paddingHorizontal: 15,
    fontSize: 12,
    color: '#999',
    fontWeight: '600',
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
    marginTop: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#EEE',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 14,
    color: '#333',
  },
  saveButton: {
    backgroundColor: '#FF69B4',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 30,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
  // Minimum order modal styles
  minimumModalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  minimumModalContent: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    width: '90%',
    maxWidth: 350,
  },
  minimumModalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 20,
    marginBottom: 15,
  },
  minimumModalText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  minimumModalSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 5,
  },
  minimumModalNeeded: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF69B4',
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 30,
  },
  minimumModalButton: {
    backgroundColor: '#FF69B4',
    borderRadius: 25,
    paddingVertical: 15,
    paddingHorizontal: 40,
    width: '100%',
    alignItems: 'center',
  },
  minimumModalButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
})

export default CheckoutScreen