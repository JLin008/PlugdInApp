import React, { useState } from 'react'
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native'
import { useForm, Controller } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
import { Ionicons } from '@expo/vector-icons'
import { supabase } from '../services/supabase'

const schema = yup.object({
  email: yup.string().email('Invalid email').required('Email is required'),
})

const ForgotPasswordScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(false)

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      email: '',
    },
  })

  const onSubmit = async (data) => {
    setLoading(true)
    try {
      // Try to send password reset email
      // Supabase will only send if user exists
      const { error } = await supabase.auth.resetPasswordForEmail(data.email)
      
      if (error) {
        console.error('Reset Password Error:', error)
        // Check the error message to determine if user doesn't exist
        if (error.message.toLowerCase().includes('user not found') || 
            error.message.toLowerCase().includes('no user found') ||
            error.message.toLowerCase().includes('cannot be found') ||
            error.status === 400) {
          Alert.alert('Error', 'No account found with this email address')
        } else {
          Alert.alert('Error', error.message)
        }
      } else {
        // Supabase successfully processed the request
        // This means the user exists and email was sent
        Alert.alert('Success', 'If an account exists with this email, you will receive a verification code')
        navigation.navigate('ResetPasswordVerify', { email: data.email })
      }
    } catch (error) {
      console.error('Catch error:', error)
      Alert.alert('Error', 'An unexpected error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="chevron-back" size={24} color="#fff" />
      </TouchableOpacity>

      <View style={styles.content}>
        <Text style={styles.title}>Reset Password</Text>
        <Text style={styles.subtitle}>
          Enter your email address and we'll send you a verification code to reset your password
        </Text>

        <Controller
          control={control}
          name="email"
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.inputContainer}>
              <Ionicons name="mail-outline" size={20} color="#FF69B4" style={styles.icon} />
              <TextInput
                style={styles.input}
                placeholder="Enter email here..."
                placeholderTextColor="#999"
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
          )}
        />
        {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}

        <TouchableOpacity
          style={styles.resetButton}
          onPress={handleSubmit(onSubmit)}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.resetButtonText}>Send Verification Code</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  backButton: {
    position: 'absolute',
    top: 50,
    left: 20,
    zIndex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2a2a2a',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
    height: 50,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    color: '#fff',
    fontSize: 14,
  },
  error: {
    color: '#FF69B4',
    fontSize: 12,
    marginBottom: 10,
    marginLeft: 5,
  },
  resetButton: {
    backgroundColor: '#333',
    borderRadius: 10,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  resetButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
})

export default ForgotPasswordScreen