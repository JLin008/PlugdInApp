import React from 'react'
import { View, Image, StyleSheet, ActivityIndicator } from 'react-native'

const SplashScreen = () => {
  return (
    <View style={styles.container}>
      <Image 
        source={require('../assets/images/plugd-logo.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <ActivityIndicator size="large" color="#FF69B4" style={styles.spinner} />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 250,
    height: 125,
    marginBottom: 50,
  },
  spinner: {
    position: 'absolute',
    bottom: 100,
  },
})

export default SplashScreen