import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Alert,
  Dimensions,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useRoute, useNavigation } from '@react-navigation/native'
import { supabase } from '../services/supabase'
import { useAuth } from '../services/authContext'
import { useCart } from '../services/cartContext'

const { width } = Dimensions.get('window')

const ProductDetailScreen = () => {
  const route = useRoute()
  const navigation = useNavigation()
  const { user } = useAuth()
  const { addToCart, cartCount, updateCartQuantity, removeFromCart } = useCart()
  const { productId } = route.params

  const [product, setProduct] = useState(null)
  const [relatedProducts, setRelatedProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedSize, setSelectedSize] = useState('3.5G')
  const [quantity, setQuantity] = useState(1)
  const [isFavorite, setIsFavorite] = useState(false)
  const [cartQuantity, setCartQuantity] = useState(0)
  const [isInCart, setIsInCart] = useState(false)

  const sizes = ['1G', '3.5G', '7G', '14G']

  useEffect(() => {
    fetchProduct()
    checkFavorite()
    checkCartStatus()
  }, [productId])

  const fetchProduct = async () => {
    try {
      // Fetch main product
      const { data: productData, error: productError } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .single()

      if (productError) throw productError
      setProduct(productData)

      // Fetch related products
      const { data: relatedData, error: relatedError } = await supabase
        .from('products')
        .select('*')
        .neq('id', productId)
        .limit(3)

      if (relatedError) throw relatedError
      setRelatedProducts(relatedData || [])
    } catch (error) {
      console.error('Error fetching product:', error)
      Alert.alert('Error', 'Failed to load product details')
    } finally {
      setLoading(false)
    }
  }

  const checkCartStatus = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select('quantity')
        .eq('user_id', user.id)
        .eq('product_id', productId)
        .maybeSingle()

      if (!error && data) {
        setIsInCart(true)
        setCartQuantity(data.quantity)
      } else {
        setIsInCart(false)
        setCartQuantity(0)
      }
    } catch (error) {
      console.error('Error checking cart status:', error)
    }
  }

  const checkFavorite = async () => {
    if (!user) return

    try {
      const { data, error } = await supabase
        .from('favorites')
        .select('id')
        .eq('user_id', user.id)
        .eq('product_id', productId)
        .single()

      if (!error && data) {
        setIsFavorite(true)
      }
    } catch (error) {
      console.error('Error checking favorite:', error)
    }
  }

  const toggleFavorite = async () => {
    if (!user) {
      Alert.alert('Sign In Required', 'Please sign in to save favorites')
      return
    }

    try {
      if (isFavorite) {
        const { error } = await supabase
          .from('favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('product_id', productId)

        if (error) throw error
        setIsFavorite(false)
      } else {
        const { error } = await supabase
          .from('favorites')
          .insert([{ user_id: user.id, product_id: productId }])

        if (error) throw error
        setIsFavorite(true)
      }
    } catch (error) {
      console.error('Error toggling favorite:', error)
      Alert.alert('Error', 'Failed to update favorites')
    }
  }

  const handleQuantityChange = (change) => {
    const newQuantity = quantity + change
    if (newQuantity >= 1 && newQuantity <= product.stock) {
      setQuantity(newQuantity)
    }
  }

  const handleUpdateCartQuantity = async (newQuantity) => {
    if (!user) {
      Alert.alert('Sign In Required', 'Please sign in to manage cart')
      return
    }

    try {
      if (newQuantity === 0) {
        await removeFromCart(productId)
        setIsInCart(false)
        setCartQuantity(0)
      } else {
        await updateCartQuantity(productId, newQuantity)
        setIsInCart(true)
        setCartQuantity(newQuantity)
      }
    } catch (error) {
      console.error('Error updating cart:', error)
      Alert.alert('Error', 'Failed to update cart')
    }
  }

  const handleAddToCart = async () => {
    if (!user) {
      Alert.alert('Sign In Required', 'Please sign in to add items to cart')
      return
    }

    try {
      await addToCart(productId, quantity)
      setIsInCart(true)
      setCartQuantity(quantity)
      Alert.alert('Success', `Added ${quantity} item(s) to cart!`)
      setQuantity(1) // Reset quantity selector
    } catch (error) {
      Alert.alert('Error', 'Failed to add to cart')
    }
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#FF69B4" style={styles.loader} />
      </SafeAreaView>
    )
  }

  if (!product) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Product not found</Text>
      </SafeAreaView>
    )
  }

  const discountedPrice = product.discount > 0
    ? (product.price - (product.price * product.discount / 100)).toFixed(2)
    : null

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>PRODUCT DETAILS</Text>
        <TouchableOpacity 
          style={styles.cartIconContainer}
          onPress={() => navigation.navigate('Cart')}
        >
          <Ionicons name="cart-outline" size={24} color="#000" />
          {cartCount > 0 && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{cartCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Product Image */}
        <View style={styles.imageContainer}>
          <Image source={{ uri: product.image_url }} style={styles.productImage} />
          <TouchableOpacity 
            style={styles.favoriteButton}
            onPress={toggleFavorite}
          >
            <Ionicons 
              name={isFavorite ? "heart" : "heart-outline"} 
              size={24} 
              color={isFavorite ? "#FF69B4" : "#888"} 
            />
          </TouchableOpacity>
        </View>

        {/* Product Info */}
        <View style={styles.productInfo}>
          <Text style={styles.productName}>{product.name}</Text>
          <Text style={styles.brandName}>BY {product.brand?.toUpperCase()}</Text>
          
          {/* Rating */}
          <View style={styles.ratingContainer}>
            {[...Array(5)].map((_, i) => (
              <Ionicons 
                key={i} 
                name="star" 
                size={16} 
                color={i < Math.floor(product.rating) ? "#FFD700" : "#DDD"} 
              />
            ))}
            <Text style={styles.ratingText}>{product.rating} ({product.review_count})</Text>
          </View>

          {/* THC/CBD Tags */}
          <View style={styles.tagsContainer}>
            {product.thc_percent > 0 && (
              <View style={styles.tag}>
                <Text style={styles.tagText}>THC {product.thc_percent}%</Text>
              </View>
            )}
            {product.cbd_percent > 0 && (
              <View style={styles.tag}>
                <Text style={styles.tagText}>CBD {product.cbd_percent}%</Text>
              </View>
            )}
            {product.type && (
              <View style={[styles.tag, { backgroundColor: '#E8F5E9' }]}>
                <Text style={[styles.tagText, { color: '#4CAF50' }]}>{product.type.toUpperCase()}</Text>
              </View>
            )}
          </View>

          {/* Price */}
          <View style={styles.priceSection}>
            <View style={styles.priceContainer}>
              {discountedPrice ? (
                <>
                  <Text style={styles.discountedPrice}>${discountedPrice}</Text>
                  <Text style={styles.originalPrice}>${product.price}</Text>
                  <View style={styles.discountBadge}>
                    <Text style={styles.discountText}>{product.discount}% OFF</Text>
                  </View>
                </>
              ) : (
                <Text style={styles.price}>${product.price}</Text>
              )}
            </View>
            <Text style={styles.stockText}>{product.stock} IN STOCK</Text>
          </View>

          <Text style={styles.pricePerGram}>PRICE PER GRAM: ${(product.price / 3.5).toFixed(2)}/G</Text>

          {/* Description */}
          <View style={styles.descriptionSection}>
            <Text style={styles.sectionTitle}>DESCRIPTION</Text>
            <Text style={styles.description}>{product.description}</Text>
          </View>

          {/* Size Selection */}
          <View style={styles.sizeSection}>
            <Text style={styles.sectionTitle}>SIZE</Text>
            <View style={styles.sizeOptions}>
              {sizes.map((size) => (
                <TouchableOpacity
                  key={size}
                  style={[
                    styles.sizeOption,
                    selectedSize === size && styles.selectedSizeOption
                  ]}
                  onPress={() => setSelectedSize(size)}
                >
                  <Text style={[
                    styles.sizeText,
                    selectedSize === size && styles.selectedSizeText
                  ]}>
                    {size}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Quantity (only shown if not in cart) */}
          {!isInCart && (
            <View style={styles.quantitySection}>
              <Text style={styles.sectionTitle}>QUANTITY</Text>
              <View style={styles.quantityControl}>
                <TouchableOpacity 
                  style={styles.quantityButton}
                  onPress={() => handleQuantityChange(-1)}
                >
                  <Ionicons name="remove" size={20} color="#000" />
                </TouchableOpacity>
                <Text style={styles.quantityText}>{quantity}</Text>
                <TouchableOpacity 
                  style={styles.quantityButton}
                  onPress={() => handleQuantityChange(1)}
                >
                  <Ionicons name="add" size={20} color="#000" />
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Cart Quantity Control (shown if in cart) */}
          {isInCart && (
            <View style={styles.quantitySection}>
              <Text style={styles.sectionTitle}>IN CART</Text>
              <View style={styles.cartQuantityControl}>
                <TouchableOpacity 
                  style={styles.cartQuantityButton}
                  onPress={() => handleUpdateCartQuantity(cartQuantity - 1)}
                >
                  <Ionicons name="remove" size={16} color="#000" />
                </TouchableOpacity>
                <Text style={styles.cartQuantityText}>{cartQuantity}</Text>
                <TouchableOpacity 
                  style={styles.cartQuantityButton}
                  onPress={() => handleUpdateCartQuantity(cartQuantity + 1)}
                >
                  <Ionicons name="add" size={16} color="#000" />
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* You Might Also Like */}
          <View style={styles.relatedSection}>
            <Text style={styles.sectionTitle}>YOU MIGHT ALSO LIKE</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {relatedProducts.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  style={styles.relatedProduct}
                  onPress={() => navigation.push('ProductDetail', { productId: item.id })}
                >
                  <TouchableOpacity 
                    style={styles.relatedFavoriteButton}
                    onPress={() => Alert.alert('Coming Soon', 'Add to favorites from main product page')}
                  >
                    <Ionicons name="heart-outline" size={16} color="#888" />
                  </TouchableOpacity>
                  <Image source={{ uri: item.image_url }} style={styles.relatedImage} />
                  <Text style={styles.relatedName} numberOfLines={1}>{item.name}</Text>
                  <Text style={styles.relatedBrand} numberOfLines={1}>{item.brand}</Text>
                  <View style={styles.relatedRating}>
                    {[...Array(5)].map((_, i) => (
                      <Ionicons 
                        key={i} 
                        name="star" 
                        size={10} 
                        color={i < Math.floor(item.rating) ? "#FFD700" : "#DDD"} 
                      />
                    ))}
                  </View>
                  <Text style={styles.relatedPrice}>${item.price}</Text>
                  <TouchableOpacity 
                    style={styles.relatedAddButton}
                    onPress={async () => {
                      try {
                        await addToCart(item.id)
                        Alert.alert('Success', 'Added to cart!')
                      } catch (error) {
                        Alert.alert('Error', 'Failed to add to cart')
                      }
                    }}
                  >
                    <Text style={styles.relatedAddText}>ADD TO CART</Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Button */}
      <View style={styles.bottomButtons}>
        {isInCart ? (
          <TouchableOpacity 
            style={styles.viewCartButton}
            onPress={() => navigation.navigate('Cart')}
          >
            <Ionicons name="cart" size={20} color="#FFF" />
            <Text style={styles.viewCartText}>VIEW CART ({cartCount} ITEMS)</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity 
            style={styles.addToCartButton}
            onPress={handleAddToCart}
          >
            <Ionicons name="cart-outline" size={20} color="#FFF" />
            <Text style={styles.addToCartText}>ADD TO CART</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    flex: 1,
    textAlign: 'center',
    marginTop: 50,
    fontSize: 16,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  cartIconContainer: {
    position: 'relative',
  },
  cartBadge: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#FF69B4',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 5,
  },
  cartBadgeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  imageContainer: {
    backgroundColor: '#FFF',
    padding: 20,
    alignItems: 'center',
  },
  productImage: {
    width: width - 80,
    height: width - 80,
    resizeMode: 'contain',
  },
  favoriteButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  productInfo: {
    backgroundColor: '#FFF',
    padding: 20,
    marginTop: 10,
  },
  productName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 5,
  },
  brandName: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  ratingText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 10,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  tag: {
    backgroundColor: '#E3F2FD',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
    marginRight: 8,
    marginBottom: 8,
  },
  tagText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#2196F3',
  },
  priceSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  price: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000',
  },
  discountedPrice: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF69B4',
  },
  originalPrice: {
    fontSize: 20,
    color: '#888',
    textDecorationLine: 'line-through',
    marginLeft: 10,
  },
  discountBadge: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    marginLeft: 10,
  },
  discountText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  stockText: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '600',
  },
  pricePerGram: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  descriptionSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 10,
  },
  description: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  sizeSection: {
    marginBottom: 20,
  },
  sizeOptions: {
    flexDirection: 'row',
  },
  sizeOption: {
    borderWidth: 1,
    borderColor: '#DDD',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginRight: 10,
  },
  selectedSizeOption: {
    backgroundColor: '#FF69B4',
    borderColor: '#FF69B4',
  },
  sizeText: {
    fontSize: 14,
    color: '#666',
  },
  selectedSizeText: {
    color: '#FFF',
    fontWeight: '600',
  },
  quantitySection: {
    marginBottom: 30,
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityButton: {
    width: 36,
    height: 36,
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: 18,
    fontWeight: '600',
    marginHorizontal: 30,
  },
  cartQuantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 4,
    alignSelf: 'flex-start',
  },
  cartQuantityButton: {
    width: 28,
    height: 28,
    borderRadius: 6,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  cartQuantityText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
    marginHorizontal: 15,
  },
  relatedSection: {
    marginBottom: 20,
  },
  relatedProduct: {
    width: 150,
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 10,
    marginRight: 12,
  },
  relatedFavoriteButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  relatedImage: {
    width: '100%',
    height: 100,
    borderRadius: 8,
    marginBottom: 8,
  },
  relatedName: {
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 2,
  },
  relatedBrand: {
    fontSize: 10,
    color: '#666',
    marginBottom: 5,
  },
  relatedRating: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  relatedPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  relatedAddButton: {
    backgroundColor: '#000',
    borderRadius: 6,
    paddingVertical: 6,
    alignItems: 'center',
  },
  relatedAddText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  bottomButtons: {
    padding: 20,
    backgroundColor: '#FFF',
    borderTopWidth: 1,
    borderTopColor: '#EEE',
  },
  addToCartButton: {
    backgroundColor: '#000',
    borderRadius: 25,
    paddingVertical: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addToCartText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
    marginLeft: 8,
  },
  viewCartButton: {
    backgroundColor: '#FF69B4',
    borderRadius: 25,
    paddingVertical: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  viewCartText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
    marginLeft: 8,
  },
})

export default ProductDetailScreen