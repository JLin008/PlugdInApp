import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  RefreshControl,
  FlatList,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { orderService } from '../services/orderService'
import { supabase } from '../services/supabase'

const AdminOrdersScreen = () => {
  const navigation = useNavigation()
  const [orders, setOrders] = useState([])
  const [filteredOrders, setFilteredOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedFilter, setSelectedFilter] = useState('all')
  const [updatingOrderId, setUpdatingOrderId] = useState(null)
  const [loadingMore, setLoadingMore] = useState(false)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  
  const ORDERS_PER_PAGE = 8

  const filters = [
    { id: 'all', label: 'ALL' },
    { id: 'pending', label: 'PENDING' },
    { id: 'in_progress', label: 'IN PROGRESS' },
    { id: 'completed', label: 'COMPLETED' },
  ]

  useEffect(() => {
    fetchOrders(true)
    
    const channel = supabase
      .channel('admin_orders_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        (payload) => {
          console.log('Real-time update received:', payload)
          fetchOrders(true)
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [selectedFilter])

  useEffect(() => {
    if (!loading) {
      filterOrders()
    }
  }, [orders, searchQuery])

  const fetchOrders = async (reset = false) => {
    if (reset) {
      setPage(1)
      setHasMore(true)
      setLoading(true)
    }
    
    try {
      console.log('Fetching orders with filter:', selectedFilter)
      
      let query = supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false })

      if (selectedFilter !== 'all') {
        query = query.or(`status.eq.${selectedFilter},status.eq.'${selectedFilter}'`)
      }

      const from = reset ? 0 : (page - 1) * ORDERS_PER_PAGE
      const to = reset ? ORDERS_PER_PAGE - 1 : page * ORDERS_PER_PAGE - 1
      
      const { data, error } = await query.range(from, to)

      if (error) {
        console.error('Query error:', error)
        throw error
      }

      console.log('Fetched orders:', data?.length || 0, 'orders')

      if (reset) {
        setOrders(data || [])
        setFilteredOrders(data || [])
        setPage(1)
      } else {
        const newOrders = [...orders, ...(data || [])]
        setOrders(newOrders)
        setFilteredOrders(newOrders)
      }

      setHasMore((data?.length || 0) === ORDERS_PER_PAGE)
      
    } catch (error) {
      console.error('Error fetching orders:', error)
      Alert.alert('Error', 'Failed to load orders')
    } finally {
      setLoading(false)
      setRefreshing(false)
      setLoadingMore(false)
    }
  }

  const loadMoreOrders = () => {
    if (!loadingMore && hasMore && !loading) {
      setLoadingMore(true)
      setPage(prev => {
        const nextPage = prev + 1
        fetchOrders(false)
        return nextPage
      })
    }
  }

  const filterOrders = () => {
    let filtered = [...orders]

    if (searchQuery) {
      filtered = filtered.filter(order => 
        order.order_number.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }

    setFilteredOrders(filtered)
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchOrders(true)
  }

  const handleSearch = (text) => {
    setSearchQuery(text)
  }

  const updateOrderStatus = async (orderId, currentStatus) => {
    setUpdatingOrderId(orderId)
    
    try {
      let newStatus
      if (currentStatus === 'pending') {
        newStatus = 'in_progress'
      } else if (currentStatus === 'in_progress') {
        newStatus = 'completed'
      } else {
        return
      }

      await orderService.updateOrderStatus(orderId, newStatus)
      
      setOrders(prevOrders => 
        prevOrders.map(order => 
          order.id === orderId ? { ...order, status: newStatus } : order
        )
      )
    } catch (error) {
      console.error('Error updating order:', error)
      Alert.alert('Error', 'Failed to update order status')
    } finally {
      setUpdatingOrderId(null)
    }
  }

  const declineOrder = async (orderId, orderItems) => {
    Alert.alert(
      'Decline Order',
      'Are you sure you want to decline this order?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Decline',
          style: 'destructive',
          onPress: async () => {
            setUpdatingOrderId(orderId)
            try {
              for (const item of orderItems) {
                const { error: stockError } = await supabase
                  .rpc('update_product_stock', {
                    product_id: item.productId,
                    quantity_change: item.quantity
                  })

                if (stockError) {
                  console.error('Error restoring stock:', stockError)
                }
              }

              const { error } = await supabase
                .from('orders')
                .update({ status: 'declined' })
                .eq('id', orderId)

              if (error) throw error

              setOrders(prevOrders => 
                prevOrders.map(order => 
                  order.id === orderId ? { ...order, status: 'declined' } : order
                )
              )

              Alert.alert('Success', 'Order has been declined and stock restored')
            } catch (error) {
              console.error('Error declining order:', error)
              Alert.alert('Error', 'Failed to decline order')
            } finally {
              setUpdatingOrderId(null)
            }
          }
        }
      ]
    )
  }

  const deleteOrder = async (orderId) => {
    Alert.alert(
      'Delete Order',
      'Are you sure you want to delete this completed order?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('orders')
                .delete()
                .eq('id', orderId)

              if (error) throw error

              setOrders(prevOrders => 
                prevOrders.filter(order => order.id !== orderId)
              )
            } catch (error) {
              console.error('Error deleting order:', error)
              Alert.alert('Error', 'Failed to delete order')
            }
          }
        }
      ]
    )
  }

  const getStatusColor = (status) => {
    const cleanStatus = status?.replace(/'/g, '').trim()
    
    switch (cleanStatus) {
      case 'pending':
        return '#FF9800'
      case 'in_progress':
        return '#2196F3'
      case 'completed':
        return '#4CAF50'
      case 'declined':
        return '#F44336'
      default:
        return '#666'
    }
  }

  const formatTime = (timestamp) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffInMinutes = Math.floor((now - date) / (1000 * 60))
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60)
      return `${hours}h ago`
    } else {
      return date.toLocaleDateString()
    }
  }

  const renderOrder = ({ item }) => {
    const isUpdating = updatingOrderId === item.id
    const cleanStatus = item.status?.replace(/'/g, '').trim()
    
    const showAcceptButton = cleanStatus === 'pending'
    const showMarkReadyButton = cleanStatus === 'in_progress'
    const showDeleteButton = cleanStatus === 'completed' || cleanStatus === 'declined'

    return (
      <View style={styles.orderCard}>
        <View style={styles.orderHeader}>
          <View>
            <Text style={styles.orderNumber}>{item.order_number}</Text>
            <Text style={styles.orderTime}>{formatTime(item.created_at)}</Text>
          </View>
          <View style={styles.headerRight}>
            <View style={[styles.statusBadge, { backgroundColor: getStatusColor(cleanStatus) }]}>
              <Text style={styles.statusText}>
                {cleanStatus.replace('_', ' ').toUpperCase()}
              </Text>
            </View>
            {showDeleteButton && (
              <TouchableOpacity
                onPress={() => deleteOrder(item.id)}
                style={styles.deleteButton}
              >
                <Ionicons name="trash-outline" size={20} color="#FF0000" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View style={styles.customerSection}>
          <View style={styles.customerInfo}>
            <Ionicons name="person-outline" size={16} color="#666" />
            <Text style={styles.customerName}>{item.customer_name}</Text>
          </View>
          <View style={styles.customerInfo}>
            <Ionicons name="location-outline" size={16} color="#666" />
            <Text style={styles.customerAddress}>{item.delivery_address}</Text>
          </View>
        </View>

        <View style={styles.itemsSection}>
          <Text style={styles.itemsTitle}>ORDER ITEMS:</Text>
          {item.items.map((orderItem, index) => (
            <View key={index} style={styles.orderItem}>
              <Text style={styles.itemName}>
                {orderItem.productName} x{orderItem.quantity}
              </Text>
              <Text style={styles.itemPrice}>${(orderItem.price * orderItem.quantity).toFixed(2)}</Text>
            </View>
          ))}
        </View>

        <View style={styles.totalSection}>
          <Text style={styles.totalLabel}>TOTAL:</Text>
          <Text style={styles.totalAmount}>${item.total.toFixed(2)}</Text>
        </View>

        {showAcceptButton && (
          <>
            <TouchableOpacity
              style={[
                styles.actionButton,
                styles.acceptButton,
                isUpdating && styles.disabledButton
              ]}
              onPress={() => updateOrderStatus(item.id, cleanStatus)}
              disabled={isUpdating}
            >
              {isUpdating ? (
                <ActivityIndicator color="#FFF" size="small" />
              ) : (
                <Text style={styles.actionButtonText}>ACCEPT</Text>
              )}
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.actionButton,
                styles.declineButton,
                isUpdating && styles.disabledButton
              ]}
              onPress={() => declineOrder(item.id, item.items)}
              disabled={isUpdating}
            >
              {isUpdating ? (
                <ActivityIndicator color="#FFF" size="small" />
              ) : (
                <Text style={styles.actionButtonText}>DECLINE</Text>
              )}
            </TouchableOpacity>
          </>
        )}

        {showMarkReadyButton && (
          <TouchableOpacity
            style={[
              styles.actionButton,
              styles.readyButton,
              isUpdating && styles.disabledButton
            ]}
            onPress={() => updateOrderStatus(item.id, cleanStatus)}
            disabled={isUpdating}
          >
            {isUpdating ? (
              <ActivityIndicator color="#FFF" size="small" />
            ) : (
              <Text style={styles.actionButtonText}>MARK READY</Text>
            )}
          </TouchableOpacity>
        )}
      </View>
    )
  }

  const renderFooter = () => {
    if (!loadingMore) return null
    return (
      <View style={styles.footerLoader}>
        <ActivityIndicator size="small" color="#FF69B4" />
      </View>
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>ORDER MANAGEMENT</Text>
          <View style={{ width: 24 }} />
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>ORDER MANAGEMENT</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={20} color="#888" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search by order number..."
            placeholderTextColor="#888"
            value={searchQuery}
            onChangeText={handleSearch}
            autoCapitalize="characters"
          />
        </View>
      </View>

      <View style={styles.filterWrapper}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.filterContainer}
          contentContainerStyle={styles.filterContentContainer}
        >
          {filters.map((filter) => (
            <TouchableOpacity
              key={filter.id}
              style={[
                styles.filterButton,
                selectedFilter === filter.id && styles.activeFilterButton
              ]}
              onPress={() => setSelectedFilter(filter.id)}
            >
              <Text style={[
                styles.filterText,
                selectedFilter === filter.id && styles.activeFilterText
              ]}>
                {filter.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredOrders}
        renderItem={renderOrder}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.ordersList}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="receipt-outline" size={60} color="#CCC" />
            <Text style={styles.emptyText}>No orders found</Text>
          </View>
        }
        onEndReached={loadMoreOrders}
        onEndReachedThreshold={0.1}
        ListFooterComponent={renderFooter}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    paddingHorizontal: 15,
    height: 45,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
    color: '#000',
  },
  filterWrapper: {
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  filterContainer: {
    paddingVertical: 10,
  },
  filterContentContainer: {
    paddingHorizontal: 20,
  },
  filterButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    marginRight: 10,
    minWidth: 80,
    alignItems: 'center',
  },
  activeFilterButton: {
    backgroundColor: '#FF69B4',
  },
  filterText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  activeFilterText: {
    color: '#FFF',
  },
  ordersList: {
    padding: 20,
    paddingBottom: 40,
  },
  orderCard: {
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  orderNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  orderTime: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFF',
  },
  deleteButton: {
    marginLeft: 10,
    padding: 5,
  },
  customerSection: {
    marginBottom: 15,
  },
  customerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  customerName: {
    fontSize: 14,
    color: '#333',
    marginLeft: 8,
    fontWeight: '500',
  },
  customerAddress: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
    flex: 1,
  },
  itemsSection: {
    borderTopWidth: 1,
    borderTopColor: '#EEE',
    paddingTop: 15,
    marginBottom: 15,
  },
  itemsTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
    marginBottom: 10,
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  itemName: {
    fontSize: 14,
    color: '#333',
    flex: 1,
  },
  itemPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  totalSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#EEE',
    paddingTop: 15,
    marginBottom: 5,
  },
  totalLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  totalAmount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  actionButton: {
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 3,
    minHeight: 50,
  },
  acceptButton: {
    backgroundColor: '#4CAF50',
  },
  readyButton: {
    backgroundColor: '#FF69B4',
  },
  declineButton: {
    backgroundColor: '#F44336',
  },
  disabledButton: {
    opacity: 0.6,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
    textTransform: 'uppercase',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 100,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
  footerLoader: {
    paddingVertical: 20,
    alignItems: 'center',
  },
})

export default AdminOrdersScreen