import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Dimensions,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { orderService } from '../services/orderService'
import { supabase } from '../services/supabase'
import { LineChart } from 'react-native-chart-kit'
import { useAuth } from '../services/authContext' // Add this import

const { width } = Dimensions.get('window')

const DispensaryHomeScreen = () => {
  const navigation = useNavigation()
  const { signOut } = useAuth() // Add this
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [metrics, setMetrics] = useState({
    todaysOrders: 0,
    pendingOrders: 0,
    completedOrders: 0,
  })
  const [weeklyTrend, setWeeklyTrend] = useState([])
  const [lowStockProducts, setLowStockProducts] = useState([])

  useEffect(() => {
    fetchDashboardData()
    
    // Subscribe to real-time order updates
    const ordersChannel = supabase
      .channel('dashboard_orders_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        (payload) => {
          console.log('Dashboard detected order change:', payload)
          // Refresh dashboard data when any order changes
          fetchDashboardData()
        }
      )
      .subscribe()

    // Subscribe to product changes to update low stock alerts
    const productsChannel = supabase
      .channel('dashboard_products_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products'
        },
        (payload) => {
          console.log('Dashboard detected product change:', payload)
          // Refresh low stock products when any product changes
          fetchLowStockProducts()
        }
      )
      .subscribe()

    // Refresh dashboard every 30 seconds
    const interval = setInterval(() => {
      fetchDashboardData()
    }, 30000)

    return () => {
      supabase.removeChannel(ordersChannel)
      supabase.removeChannel(productsChannel)
      clearInterval(interval)
    }
  }, [])

  const fetchDashboardData = async () => {
    try {
      const [metricsData, trendData, stockData] = await Promise.all([
        orderService.getDashboardMetrics(),
        orderService.getWeeklyOrdersTrend(),
        orderService.getLowStockProducts(),
      ])

      setMetrics(metricsData)
      setWeeklyTrend(trendData)
      setLowStockProducts(stockData)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  // Separate function to fetch only low stock products
  const fetchLowStockProducts = async () => {
    try {
      const stockData = await orderService.getLowStockProducts()
      setLowStockProducts(stockData)
    } catch (error) {
      console.error('Error fetching low stock products:', error)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchDashboardData()
  }

  const getChartData = () => {
    if (weeklyTrend.length === 0) {
      return {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{ data: [0, 0, 0, 0, 0, 0, 0] }]
      }
    }

    return {
      labels: weeklyTrend.map(day => day.day),
      datasets: [{
        data: weeklyTrend.map(day => day.count)
      }]
    }
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>DISPENSARY DASHBOARD</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>DISPENSARY DASHBOARD</Text>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
      >
        {/* Welcome Section */}
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeText}>Welcome back,</Text>
          <Text style={styles.adminName}>Dispensary Admin</Text>
        </View>

        {/* Metrics Cards */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.metricsContainer}
        >
          {/* Today's Orders */}
          <View style={[styles.metricCard, { backgroundColor: '#E8F5E9' }]}>
            <View style={styles.metricHeader}>
              <Ionicons name="cart-outline" size={24} color="#4CAF50" />
            </View>
            <Text style={styles.metricLabel}>TODAY'S ORDERS</Text>
            <Text style={styles.metricValue}>{metrics.todaysOrders}</Text>
          </View>

          {/* Pending Orders */}
          <View style={[styles.metricCard, { backgroundColor: '#FFF3E0' }]}>
            <View style={styles.metricHeader}>
              <Ionicons name="time-outline" size={24} color="#FF9800" />
            </View>
            <Text style={styles.metricLabel}>PENDING ORDERS</Text>
            <Text style={styles.metricValue}>{metrics.pendingOrders}</Text>
          </View>

          {/* Completed */}
          <View style={[styles.metricCard, { backgroundColor: '#E3F2FD' }]}>
            <View style={styles.metricHeader}>
              <Ionicons name="checkmark-circle-outline" size={24} color="#2196F3" />
            </View>
            <Text style={styles.metricLabel}>COMPLETED</Text>
            <Text style={styles.metricValue}>{metrics.completedOrders}</Text>
          </View>
        </ScrollView>

        {/* Weekly Orders Trend */}
        <View style={styles.chartSection}>
          <Text style={styles.sectionTitle}>Weekly Orders Trend</Text>
          {weeklyTrend.length > 0 ? (
            <LineChart
              data={getChartData()}
              width={width - 40}
              height={200}
              chartConfig={{
                backgroundColor: '#FFF',
                backgroundGradientFrom: '#FFF',
                backgroundGradientTo: '#FFF',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(255, 105, 180, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                propsForDots: {
                  r: '6',
                  strokeWidth: '2',
                  stroke: '#FF69B4',
                },
              }}
              bezier
              style={{
                marginVertical: 8,
                borderRadius: 16,
              }}
            />
          ) : (
            <View style={styles.noDataContainer}>
              <Text style={styles.noDataText}>No order data available</Text>
            </View>
          )}
        </View>

        {/* Low Stock Alerts */}
        <View style={styles.stockSection}>
          <View style={styles.stockHeader}>
            <Text style={styles.sectionTitle}>LOW STOCK ALERTS</Text>
            <TouchableOpacity onPress={fetchLowStockProducts}>
              <Ionicons name="refresh-outline" size={20} color="#666" />
            </TouchableOpacity>
          </View>
          {lowStockProducts.length === 0 ? (
            <Text style={styles.noStockAlerts}>All products are well stocked!</Text>
          ) : (
            lowStockProducts.map((product) => (
              <TouchableOpacity 
                key={product.id} 
                style={styles.stockItem}
                onPress={() => navigation.navigate('Inventory')}
              >
                <View style={styles.stockInfo}>
                  <Text style={styles.stockProductName}>{product.name}</Text>
                  <Text style={styles.stockBrand}>{product.brand}</Text>
                </View>
                <View 
                  style={[
                    styles.stockBadge,
                    product.stock < 10 && styles.criticalStockBadge
                  ]}
                >
                  <Text 
                    style={[
                      styles.stockCount,
                      product.stock < 10 && styles.criticalStockText
                    ]}
                  >
                    {product.stock} LEFT
                  </Text>
                </View>
              </TouchableOpacity>
            ))
          )}
        </View>

        {/* Manage Orders Button */}
        <TouchableOpacity 
          style={styles.manageOrdersButton}
          onPress={() => {
            console.log('Manage Orders button pressed, navigating to Orders tab');
            navigation.navigate('Orders');
          }}
        >
          <Text style={styles.manageOrdersText}>MANAGE ORDERS</Text>
        </TouchableOpacity>

        {/* Add a Product Button */}
        <TouchableOpacity 
          style={[styles.manageOrdersButton, { backgroundColor: '#4CAF50' }]}
          onPress={() => {
            console.log('Add Product button pressed, navigating to Inventory tab');
            navigation.navigate('Inventory');
          }}
        >
          <Text style={styles.manageOrdersText}>ADD A PRODUCT</Text>
        </TouchableOpacity>

        {/* Sign Out Button - FIXED */}
        <TouchableOpacity 
          style={[styles.manageOrdersButton, { backgroundColor: '#FF1744', marginBottom: 50 }]}
          onPress={async () => {
            Alert.alert(
              'Sign Out',
              'Are you sure you want to sign out?',
              [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Sign Out',
                  style: 'destructive',
                  onPress: async () => {
                    try {
                      await signOut() // Use signOut from auth context
                    } catch (error) {
                      console.error('Sign out error:', error)
                      Alert.alert('Error', 'Failed to sign out')
                    }
                  }
                }
              ]
            )
          }}
        >
          <Text style={styles.manageOrdersText}>SIGN OUT</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    backgroundColor: '#FFF',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeSection: {
    paddingHorizontal: 20,
    paddingTop: 20,
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666',
  },
  adminName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
  },
  metricsContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  metricCard: {
    width: 150,
    padding: 20,
    borderRadius: 15,
    marginRight: 15,
  },
  metricHeader: {
    marginBottom: 10,
  },
  metricLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  metricValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#000',
  },
  chartSection: {
    backgroundColor: '#FFF',
    margin: 20,
    padding: 20,
    borderRadius: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 15,
  },
  noDataContainer: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noDataText: {
    color: '#666',
    fontSize: 14,
  },
  stockSection: {
    backgroundColor: '#FFF',
    marginHorizontal: 20,
    marginBottom: 20,
    padding: 20,
    borderRadius: 15,
  },
  stockHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  noStockAlerts: {
    color: '#4CAF50',
    fontSize: 14,
    textAlign: 'center',
    paddingVertical: 20,
  },
  stockItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  stockInfo: {
    flex: 1,
  },
  stockProductName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
  },
  stockBrand: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  stockBadge: {
    backgroundColor: '#FFF3E0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
  },
  criticalStockBadge: {
    backgroundColor: '#FFCDD2',
  },
  stockCount: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FF9800',
  },
  criticalStockText: {
    color: '#F44336',
  },
  manageOrdersButton: {
    backgroundColor: '#FF69B4',
    marginHorizontal: 20,
    marginBottom: 30,
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
  },
  manageOrdersText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
})

export default DispensaryHomeScreen