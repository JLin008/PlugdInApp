import React, { useState, useEffect, useCallback } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Image,
  Modal,
  KeyboardAvoidingView,
  Platform,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { supabase } from '../services/supabase'
import * as ImagePicker from 'expo-image-picker'
import { decode } from 'base64-arraybuffer'

// Separate Modal Component to prevent re-renders
const ProductModal = ({ visible, onClose, product, onSave, isNew }) => {
  // Local state for form data
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    price: '',
    stock: '',
    description: '',
    thc_percent: '',
    cbd_percent: '',
    type: '',
    brand: '',
    discount: '0',
    rating: '0',
    review_count: '0',
    image_url: '',
  })
  const [loading, setLoading] = useState(false)
  const [imageLoading, setImageLoading] = useState(false)

  // Initialize form data when modal opens
  useEffect(() => {
    if (visible) {
      if (product && !isNew) {
        // Edit mode - populate with existing data
        setFormData({
          name: product.name || '',
          category: product.category || '',
          price: product.price?.toString() || '',
          stock: product.stock?.toString() || '',
          description: product.description || '',
          thc_percent: product.thc_percent?.toString() || '',
          cbd_percent: product.cbd_percent?.toString() || '',
          type: product.type || '',
          brand: product.brand || '',
          discount: product.discount?.toString() || '0',
          rating: product.rating?.toString() || '0',
          review_count: product.review_count?.toString() || '0',
          image_url: product.image_url || '',
        })
      } else {
        // Add mode - reset to empty
        setFormData({
          name: '',
          category: '',
          price: '',
          stock: '',
          description: '',
          thc_percent: '',
          cbd_percent: '',
          type: '',
          brand: '',
          discount: '0',
          rating: '0',
          review_count: '0',
          image_url: '',
        })
      }
    }
  }, [visible, product, isNew])

  const pickImage = async () => {
    try {
      // Request permissions
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync()
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'We need camera roll permissions to upload images.')
        return
      }

      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: 'images',
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      })

      if (!result.canceled) {
        setImageLoading(true)
        
        try {
          // Upload to Supabase Storage
          const fileName = `product-${Date.now()}.jpg`
          const photo = result.assets[0]
          
          // For React Native, we need to handle the file differently
          const formData = new FormData()
          formData.append('file', {
            uri: photo.uri,
            name: fileName,
            type: 'image/jpeg'
          })

          // Upload using Supabase storage API directly
          const { data, error } = await supabase.storage
            .from('product-images')
            .upload(fileName, formData, {
              cacheControl: '3600',
              upsert: false
            })

          if (error) {
            // If FormData doesn't work, try base64 approach
            const response = await fetch(photo.uri)
            const blob = await response.blob()
            
            const { data: retryData, error: retryError } = await supabase.storage
              .from('product-images')
              .upload(fileName, blob, {
                contentType: 'image/jpeg',
                cacheControl: '3600',
              })
            
            if (retryError) {
              Alert.alert('Upload Error', retryError.message)
            } else {
              // Get public URL
              const { data: { publicUrl } } = supabase.storage
                .from('product-images')
                .getPublicUrl(fileName)
              
              setFormData(prev => ({ ...prev, image_url: publicUrl }))
            }
          } else {
            // Get public URL
            const { data: { publicUrl } } = supabase.storage
              .from('product-images')
              .getPublicUrl(fileName)
            
            setFormData(prev => ({ ...prev, image_url: publicUrl }))
          }
        } catch (error) {
          console.error('Image upload error:', error)
          Alert.alert('Error', 'Failed to upload image')
        } finally {
          setImageLoading(false)
        }
      }
    } catch (error) {
      setImageLoading(false)
      Alert.alert('Error', 'Failed to pick image')
    }
  }

  const handleSave = async () => {
    // Validation
    if (!formData.name || !formData.category || !formData.price || !formData.stock) {
      Alert.alert('Error', 'Please fill in all required fields')
      return
    }

    setLoading(true)
    try {
      const productData = {
        name: formData.name,
        category: formData.category.toLowerCase(),
        price: parseFloat(formData.price),
        stock: parseInt(formData.stock),
        description: formData.description,
        thc_percent: formData.thc_percent ? parseFloat(formData.thc_percent) : 0,
        cbd_percent: formData.cbd_percent ? parseFloat(formData.cbd_percent) : 0,
        type: formData.type,
        brand: formData.brand,
        discount: parseFloat(formData.discount) || 0,
        rating: parseFloat(formData.rating) || 0,
        review_count: parseInt(formData.review_count) || 0,
        image_url: formData.image_url || 'https://via.placeholder.com/150',
      }

      await onSave(productData)
      onClose()
    } catch (error) {
      console.error('Modal save error:', error)
      // Error is already handled in parent component
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.modalKeyboardView}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {isNew ? 'Add New Product' : 'Edit Product'}
              </Text>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={24} color="#000" />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Image Picker */}
              <TouchableOpacity 
                style={styles.imagePicker}
                onPress={pickImage}
                disabled={imageLoading}
              >
                {imageLoading ? (
                  <ActivityIndicator size="large" color="#FF69B4" />
                ) : formData.image_url ? (
                  <Image source={{ uri: formData.image_url }} style={styles.productImagePreview} />
                ) : (
                  <>
                    <Ionicons name="camera-outline" size={40} color="#666" />
                    <Text style={styles.imagePickerText}>Add Product Image</Text>
                  </>
                )}
              </TouchableOpacity>

              {/* Form Fields */}
              <Text style={styles.inputLabel}>Product Name *</Text>
              <TextInput
                style={styles.input}
                value={formData.name}
                onChangeText={(text) => setFormData(prev => ({ ...prev, name: text }))}
                placeholder="e.g. Blue Dream"
              />

              <Text style={styles.inputLabel}>Category *</Text>
              <TextInput
                style={styles.input}
                value={formData.category}
                onChangeText={(text) => setFormData(prev => ({ ...prev, category: text }))}
                placeholder="e.g. flower, edibles, vapes"
              />

              <Text style={styles.inputLabel}>Brand</Text>
              <TextInput
                style={styles.input}
                value={formData.brand}
                onChangeText={(text) => setFormData(prev => ({ ...prev, brand: text }))}
                placeholder="e.g. Premium Cannabis Co."
              />

              <View style={styles.row}>
                <View style={styles.halfInput}>
                  <Text style={styles.inputLabel}>Price ($) *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.price}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, price: text }))}
                    placeholder="0.00"
                    keyboardType="decimal-pad"
                  />
                </View>
                <View style={styles.halfInput}>
                  <Text style={styles.inputLabel}>Stock *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.stock}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, stock: text }))}
                    placeholder="0"
                    keyboardType="number-pad"
                  />
                </View>
              </View>

              <View style={styles.row}>
                <View style={styles.halfInput}>
                  <Text style={styles.inputLabel}>THC %</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.thc_percent}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, thc_percent: text }))}
                    placeholder="0.0"
                    keyboardType="decimal-pad"
                  />
                </View>
                <View style={styles.halfInput}>
                  <Text style={styles.inputLabel}>CBD %</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.cbd_percent}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, cbd_percent: text }))}
                    placeholder="0.0"
                    keyboardType="decimal-pad"
                  />
                </View>
              </View>

              <Text style={styles.inputLabel}>Type</Text>
              <TextInput
                style={styles.input}
                value={formData.type}
                onChangeText={(text) => setFormData(prev => ({ ...prev, type: text }))}
                placeholder="e.g. Sativa, Indica, Hybrid"
              />

              <Text style={styles.inputLabel}>Discount %</Text>
              <TextInput
                style={styles.input}
                value={formData.discount}
                onChangeText={(text) => setFormData(prev => ({ ...prev, discount: text }))}
                placeholder="0"
                keyboardType="number-pad"
              />

              <View style={styles.row}>
                <View style={styles.halfInput}>
                  <Text style={styles.inputLabel}>Rating (0-5)</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.rating}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, rating: text }))}
                    placeholder="0.0"
                    keyboardType="decimal-pad"
                  />
                </View>
                <View style={styles.halfInput}>
                  <Text style={styles.inputLabel}>Review Count</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.review_count}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, review_count: text }))}
                    placeholder="0"
                    keyboardType="number-pad"
                  />
                </View>
              </View>

              <Text style={styles.inputLabel}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.description}
                onChangeText={(text) => setFormData(prev => ({ ...prev, description: text }))}
                placeholder="Product description..."
                multiline
                numberOfLines={4}
              />

              {/* Action Buttons */}
              <TouchableOpacity 
                style={[styles.saveButton, loading && styles.disabledButton]}
                onPress={handleSave}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.saveButtonText}>
                    {isNew ? 'Add Product' : 'Save Changes'}
                  </Text>
                )}
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={onClose}
                disabled={loading}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  )
}

const DispensaryInventoryScreen = () => {
  const navigation = useNavigation()
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [isNewProduct, setIsNewProduct] = useState(false)

  useEffect(() => {
    fetchProducts()
    
    // Subscribe to real-time changes
    const subscription = supabase
      .channel('products_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products'
        },
        (payload) => {
          console.log('Product change detected:', payload)
          // Refresh products when any change happens
          fetchProducts()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [])

  useEffect(() => {
    filterProducts()
  }, [products, searchQuery])

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setProducts(data || [])
    } catch (error) {
      console.error('Error fetching products:', error)
      Alert.alert('Error', 'Failed to load products')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const filterProducts = () => {
    if (!searchQuery) {
      setFilteredProducts(products)
    } else {
      const filtered = products.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.brand?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category?.toLowerCase().includes(searchQuery.toLowerCase())
      )
      setFilteredProducts(filtered)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchProducts()
  }

  const getStockStatus = (stock) => {
    if (stock === 0) return { text: 'OUT OF STOCK', color: '#FF0000' }
    if (stock < 20) return { text: 'LOW STOCK', color: '#FF9800' }
    return { text: 'IN STOCK', color: '#4CAF50' }
  }

  const handleDelete = async (productId, productName) => {
    Alert.alert(
      'Delete Product',
      `Are you sure you want to delete "${productName}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('products')
                .delete()
                .eq('id', productId)

              if (error) {
                console.error('Delete error details:', error)
                Alert.alert('Database Error', `Failed to delete product: ${error.message}`)
                // Refresh products to restore the list
                fetchProducts()
                return
              }
              
              // Remove from local state immediately
              setProducts(prev => prev.filter(p => p.id !== productId))
              Alert.alert('Success', 'Product deleted successfully')
            } catch (error) {
              console.error('Error deleting product:', error)
              Alert.alert('Error', 'Failed to delete product')
              // Refresh to restore the list
              fetchProducts()
            }
          }
        }
      ]
    )
  }

  const handleEdit = (product) => {
    setSelectedProduct(product)
    setIsNewProduct(false)
    setShowModal(true)
  }

  const handleAddNew = () => {
    setSelectedProduct(null)
    setIsNewProduct(true)
    setShowModal(true)
  }

  const handleSaveProduct = async (productData) => {
    try {
      if (isNewProduct) {
        // Insert new product
        const { data, error } = await supabase
          .from('products')
          .insert([productData])
          .select()

        if (error) {
          console.error('Insert error details:', error)
          Alert.alert('Database Error', `Failed to add product: ${error.message}`)
          throw error
        }
        Alert.alert('Success', 'Product added successfully')
      } else {
        // Update existing product
        const { data, error } = await supabase
          .from('products')
          .update(productData)
          .eq('id', selectedProduct.id)
          .select()

        if (error) {
          console.error('Update error details:', error)
          Alert.alert('Database Error', `Failed to update product: ${error.message}`)
          throw error
        }
        Alert.alert('Success', 'Product updated successfully')
      }
      
      // Refresh products
      fetchProducts()
    } catch (error) {
      console.error('Error saving product:', error)
      // Don't throw error again since we already showed alert
    }
  }

  const renderProduct = (product) => {
    const stockStatus = getStockStatus(product.stock)
    const pricePerGram = product.price ? (product.price / 3.5).toFixed(2) : '0.00'

    return (
      <View key={product.id} style={styles.productCard}>
        <Image 
          source={{ uri: product.image_url || 'https://via.placeholder.com/150' }} 
          style={styles.productImage}
        />
        
        <View style={styles.productInfo}>
          <Text style={styles.productName}>{product.name}</Text>
          <Text style={styles.productCategory}>{product.category?.toUpperCase()}</Text>
          <Text style={styles.productPrice}>${product.price} / GRAM</Text>
          
          <View style={[styles.stockBadge, { backgroundColor: stockStatus.color }]}>
            <Text style={styles.stockText}>{stockStatus.text}</Text>
          </View>
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity onPress={() => handleDelete(product.id, product.name)}>
            <Ionicons name="trash-outline" size={24} color="#FF0000" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleEdit(product)}>
            <Ionicons name="create-outline" size={24} color="#000" />
          </TouchableOpacity>
        </View>
      </View>
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>PRODUCT</Text>
          <TouchableOpacity 
            style={styles.addButton}
            onPress={handleAddNew}
          >
            <Text style={styles.addButtonText}>ADD PRODUCT</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>PRODUCT</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={handleAddNew}
        >
          <Text style={styles.addButtonText}>ADD PRODUCT</Text>
        </TouchableOpacity>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={20} color="#888" />
          <TextInput
            style={styles.searchInput}
            placeholder="SEARCH HERE"
            placeholderTextColor="#888"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      {/* Products List */}
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
        contentContainerStyle={styles.scrollContent}
      >
        {filteredProducts.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="cube-outline" size={60} color="#CCC" />
            <Text style={styles.emptyText}>No products found</Text>
            <TouchableOpacity 
              style={styles.emptyAddButton}
              onPress={handleAddNew}
            >
              <Text style={styles.emptyAddButtonText}>Add Your First Product</Text>
            </TouchableOpacity>
          </View>
        ) : (
          filteredProducts.map(renderProduct)
        )}
      </ScrollView>

      {/* Product Modal */}
      <ProductModal
        visible={showModal}
        onClose={() => setShowModal(false)}
        product={selectedProduct}
        onSave={handleSaveProduct}
        isNew={isNewProduct}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  addButton: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 25,
    paddingHorizontal: 15,
    height: 45,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
    color: '#000',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  productCard: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 15,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 15,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  productPrice: {
    fontSize: 14,
    color: '#000',
    marginBottom: 8,
  },
  stockBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  stockText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#FFF',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 15,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 100,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
    marginBottom: 30,
  },
  emptyAddButton: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  emptyAddButtonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalKeyboardView: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 20,
    paddingHorizontal: 20,
    paddingBottom: 40,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  imagePicker: {
    backgroundColor: '#F5F5F5',
    height: 150,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  productImagePreview: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
  },
  imagePickerText: {
    fontSize: 14,
    color: '#666',
    marginTop: 10,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
    marginTop: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#EEE',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 14,
    color: '#333',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  row: {
    flexDirection: 'row',
    gap: 10,
  },
  halfInput: {
    flex: 1,
  },
  saveButton: {
    backgroundColor: '#FF69B4',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 30,
  },
  disabledButton: {
    opacity: 0.6,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
  cancelButton: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 25,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  cancelButtonText: {
    fontSize: 16,
    color: '#666',
  },
})

export default DispensaryInventoryScreen