import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
  Alert,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { orderService } from '../services/orderService'
import { LineChart } from 'react-native-chart-kit'

const { width } = Dimensions.get('window')

const DispensaryReportsScreen = () => {
  const navigation = useNavigation()
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [totalRevenue, setTotalRevenue] = useState(0)
  const [productsSold, setProductsSold] = useState(0)
  const [revenueData, setRevenueData] = useState([])

  useEffect(() => {
    fetchReportData()
  }, [])

  const fetchReportData = async () => {
    try {
      const [revenue, products, dailyRevenue] = await Promise.all([
        orderService.getTotalRevenue(),
        orderService.getProductsSoldCount(),
        orderService.getDailyRevenue(),
      ])

      setTotalRevenue(revenue)
      setProductsSold(products)
      setRevenueData(dailyRevenue)
    } catch (error) {
      console.error('Error fetching report data:', error)
      Alert.alert('Error', 'Failed to load report data')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchReportData()
  }

  const getChartData = () => {
    // Use the revenue data that's already processed by orderService
    // It should already have all 7 days in order
    if (!revenueData || revenueData.length === 0) {
      // Return empty week if no data
      const emptyWeek = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']
      return {
        labels: emptyWeek,
        datasets: [{
          data: [0, 0, 0, 0, 0, 0, 0],
          color: (opacity = 1) => `rgba(249, 111, 111, ${opacity})`,
          strokeWidth: 3
        }]
      }
    }
    
    const chartData = {
      labels: revenueData.map(d => d.day.toUpperCase()),
      datasets: [{
        data: revenueData.map(d => {
          const value = parseFloat(d.revenue) || 0
          return value
        }),
        color: (opacity = 1) => `rgba(249, 111, 111, ${opacity})`,
        strokeWidth: 3
      }]
    }
    
    return chartData
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>REPORTS & ANALYTICS</Text>
          <View style={{ width: 24 }} />
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  const chartData = getChartData()
  const hasRevenue = revenueData.some(d => parseFloat(d.revenue) > 0)

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>REPORTS & ANALYTICS</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
      >
        {/* Monthly Tab */}
        <View style={styles.tabContainer}>
          <TouchableOpacity style={styles.activeTab}>
            <Text style={styles.activeTabText}>WEEKLY</Text>
          </TouchableOpacity>
        </View>

        {/* Stats Row */}
        <View style={styles.statsRow}>
          {/* Total Revenue */}
          <View style={styles.statCard}>
            <View style={styles.statHeader}>
              <Ionicons name="cart-outline" size={24} color="#FF69B4" />
            </View>
            <Text style={styles.statLabel}>TOTAL REVENUE</Text>
            <Text style={[styles.statValue, { color: '#F96F6F' }]}>
              ${totalRevenue.toFixed(2)}
            </Text>
          </View>

          {/* Products Sold */}
          <View style={styles.statCard}>
            <View style={styles.statHeader}>
              <View style={styles.iconCircle}>
                <Ionicons name="cube-outline" size={24} color="#FFB74D" />
              </View>
            </View>
            <Text style={styles.statLabel}>PRODUCTS SOLD</Text>
            <Text style={[styles.statValue, { color: '#000' }]}>
              {productsSold}
            </Text>
          </View>
        </View>

        {/* Revenue Trend Graph */}
        <View style={styles.graphSection}>
          <Text style={styles.graphTitle}>REVENUE TREND (LAST 7 DAYS)</Text>
          
          <View style={{ marginHorizontal: -10 }}>
            <LineChart
              data={chartData}
              width={width - 40}
              height={220}
              chartConfig={{
                backgroundColor: '#FFF',
                backgroundGradientFrom: '#FFF',
                backgroundGradientTo: '#FFF',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(249, 111, 111, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                propsForDots: {
                  r: '5',
                  strokeWidth: '2',
                  stroke: '#F96F6F',
                  fill: '#F96F6F',
                },
                propsForBackgroundLines: {
                  strokeDasharray: '', // solid lines
                  stroke: '#E0E0E0',
                  strokeWidth: 1,
                },
                fillShadowGradient: '#FFE0E0',
                fillShadowGradientOpacity: 0.3,
                fillShadowGradientFrom: '#F96F6F',
                fillShadowGradientTo: '#FFFFFF',
                propsForLabels: {
                  fontSize: 9,
                },
                propsForVerticalLabels: {
                  fontSize: 9,
                },
                propsForHorizontalLabels: {
                  fontSize: 9,
                },
              }}
              bezier
              style={{
                marginVertical: 8,
                borderRadius: 16,
                paddingRight: 35,
              }}
              withInnerLines={true}
              withOuterLines={false}
              withHorizontalLines={true}
              withVerticalLines={false}
              withDots={true}
              withShadow={false}
              fromZero={true}
              segments={4}
              yAxisLabel=""
              yAxisSuffix=""
              yAxisInterval={1}
              formatYLabel={(value) => {
                if (value >= 1000) {
                  return `$${Math.round(value / 100) / 10}k`
                }
                return `$${Math.round(value)}`
              }}
              getDotColor={(dataPoint, index) => '#F96F6F'}
              xLabelsOffset={-5}
              yLabelsOffset={5}
            />
          </View>
          {!hasRevenue && (
            <Text style={styles.noRevenueNote}>
              Add orders to see revenue trends over time.
            </Text>
          )}
        </View>

        {/* Spacer */}
        <View style={{ height: 50 }} />
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
    marginBottom: 20,
  },
  activeTab: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 25,
    paddingVertical: 10,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  activeTabText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 15,
    marginBottom: 30,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  statHeader: {
    marginBottom: 15,
  },
  iconCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFF3E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 11,
    color: '#999',
    marginBottom: 8,
    fontWeight: '600',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  graphSection: {
    backgroundColor: '#FFF',
    marginHorizontal: 20,
    padding: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
    overflow: 'hidden',
  },
  graphTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 20,
  },
  noRevenueNote: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    marginTop: 10,
    fontStyle: 'italic',
  },
})

export default DispensaryReportsScreen