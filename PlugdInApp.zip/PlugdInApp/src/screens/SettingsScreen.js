import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { useAuth } from '../services/authContext'
import { useCart } from '../services/cartContext'

const SettingsScreen = () => {
  const navigation = useNavigation()
  const { user, signOut } = useAuth()
  const { profile: contextProfile } = useCart()

  const handleSignOut = async () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            await signOut()
            // Navigation is handled in authContext
          }
        }
      ]
    )
  }

  const handleSignIn = () => {
    navigation.navigate('Auth', { screen: 'SignIn' })
  }

  const handleEditProfile = () => {
    if (!user) {
      Alert.alert(
        'Sign In Required',
        'Please sign in to edit your profile',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Sign In', onPress: handleSignIn }
        ]
      )
      return
    }
    // Add edit profile functionality here if needed
    Alert.alert('Coming Soon', 'Profile editing will be available soon!')
  }

  // Get first letter of email for avatar
  const getInitial = () => {
    if (!user) return 'G'
    const email = contextProfile?.email || user?.email || 'U'
    return email.charAt(0).toUpperCase()
  }

  // Get display name
  const getDisplayName = () => {
    if (!user) return 'Guest'
    return contextProfile?.name || user?.email?.split('@')[0] || 'User'
  }

  const getEmail = () => {
    if (!user) return 'Sign in to view your email'
    return contextProfile?.email || user?.email
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('HomeTab')}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>SETTINGS</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
          <Ionicons name="notifications-outline" size={24} color="#000" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Section */}
        <View style={styles.profileSection}>
          <View style={styles.profileImageContainer}>
            <Text style={styles.profileInitial}>{getInitial()}</Text>
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{getDisplayName()}</Text>
            <Text style={styles.profileEmail}>{getEmail()}</Text>
          </View>
        </View>

        {/* Wallet Section */}
        <View style={styles.walletSection}>
          <Text style={styles.walletTitle}>WALLET</Text>
          <Text style={styles.walletLabel}>AVAILABLE BALANCE</Text>
          <Text style={styles.walletAmount}>$47.25</Text>
          <View style={styles.walletButtons}>
            <TouchableOpacity 
              style={styles.addFundsButton}
              onPress={() => {
                if (!user) {
                  Alert.alert(
                    'Sign In Required',
                    'Please sign in to add funds',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Sign In', onPress: handleSignIn }
                    ]
                  )
                  return
                }
                Alert.alert('Coming Soon', 'Add funds feature coming soon!')
              }}
            >
              <Text style={styles.addFundsText}>ADD FUNDS</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.viewCardsButton}
              onPress={() => {
                if (!user) {
                  Alert.alert(
                    'Sign In Required',
                    'Please sign in to view cards',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Sign In', onPress: handleSignIn }
                    ]
                  )
                  return
                }
                Alert.alert('Coming Soon', 'View cards feature coming soon!')
              }}
            >
              <Text style={styles.viewCardsText}>VIEW CARDS</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Settings Options - Only Help & Support and Terms & Conditions */}
        <TouchableOpacity 
          style={styles.settingItem}
          onPress={() => navigation.navigate('HelpCenter')}
        >
          <View style={styles.settingLeft}>
            <View style={[styles.iconContainer, { backgroundColor: '#FFE4E1' }]}>
              <Ionicons name="help-circle-outline" size={20} color="#FF69B4" />
            </View>
            <View>
              <Text style={styles.settingTitle}>Help & Support</Text>
              <Text style={styles.settingSubtitle}>Get help and contact support</Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#999" />
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.settingItem}
          onPress={() => navigation.navigate('TermsAndConditions')}
        >
          <View style={styles.settingLeft}>
            <View style={[styles.iconContainer, { backgroundColor: '#FFE4E1' }]}>
              <Ionicons name="document-text-outline" size={20} color="#FF69B4" />
            </View>
            <View>
              <Text style={styles.settingTitle}>Terms & Conditions</Text>
              <Text style={styles.settingSubtitle}>Legal terms and policies</Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#999" />
        </TouchableOpacity>

        {/* Sign In/Out Button */}
        {user ? (
          <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.signInButton} onPress={handleSignIn}>
            <Text style={styles.signInText}>Sign In</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 20,
    marginBottom: 10,
  },
  profileImageContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#FF69B4',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  profileInitial: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFF',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    color: '#666',
  },
  walletSection: {
    backgroundColor: '#FFF',
    padding: 20,
    marginBottom: 10,
  },
  walletTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 10,
  },
  walletLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  walletAmount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 20,
  },
  walletButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  addFundsButton: {
    flex: 1,
    backgroundColor: '#000',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  addFundsText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  viewCardsButton: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  viewCardsText: {
    color: '#666',
    fontSize: 12,
    fontWeight: 'bold',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F5F5F5',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  settingSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  signOutButton: {
    backgroundColor: '#FF1744',
    marginHorizontal: 20,
    marginVertical: 30,
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
  },
  signOutText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  signInButton: {
    backgroundColor: '#FF69B4',
    marginHorizontal: 20,
    marginVertical: 30,
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
  },
  signInText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
})

export default SettingsScreen