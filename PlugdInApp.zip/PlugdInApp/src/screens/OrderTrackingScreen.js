import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { supabase } from '../services/supabase'
import { useAuth } from '../services/authContext'

const OrderTrackingScreen = () => {
  const navigation = useNavigation()
  const { user } = useAuth()
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    if (user && user.id) {
      fetchOrders()

      // Subscribe to order updates
      const channel = supabase
        .channel('customer_orders')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'orders',
            filter: `user_id=eq.${user.id}`
          },
          () => {
            fetchOrders()
          }
        )
        .subscribe()

      return () => {
        supabase.removeChannel(channel)
      }
    } else {
      // For guest users, just set loading to false
      setLoading(false)
    }
  }, [user])

  const fetchOrders = async () => {
    if (!user || !user.id) {
      console.log('No user found')
      setLoading(false)
      setRefreshing(false)
      return
    }

    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)

      if (error) throw error
      setOrders(data || [])
    } catch (error) {
      console.error('Error fetching orders:', error)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchOrders()
  }

  const getOrderStatus = (status) => {
    // Clean the status
    const cleanStatus = status?.replace(/'/g, '').trim()
    
    return {
      orderPlaced: true,
      orderConfirmed: cleanStatus === 'pending' || cleanStatus === 'in_progress' || cleanStatus === 'completed',
      outForDelivery: cleanStatus === 'in_progress' || cleanStatus === 'completed',
      orderArrived: cleanStatus === 'completed',
      orderDeclined: cleanStatus === 'declined'
    }
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', { 
      day: '2-digit', 
      month: 'short', 
      year: 'numeric' 
    }).toUpperCase()
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.navigate('HomeTab', { screen: 'Home' })}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>ORDER TRACKING</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
            <Ionicons name="notifications-outline" size={24} color="#000" />
          </TouchableOpacity>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  // Check if user is not signed in
  if (!user) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.navigate('HomeTab', { screen: 'Home' })}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>ORDER TRACKING</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
            <Ionicons name="notifications-outline" size={24} color="#000" />
          </TouchableOpacity>
        </View>
        <View style={styles.guestContainer}>
          <Ionicons name="person-outline" size={60} color="#CCC" />
          <Text style={styles.guestTitle}>Sign In Required</Text>
          <Text style={styles.guestText}>Please sign in to view your orders</Text>
          <TouchableOpacity 
            style={styles.signInButton}
            onPress={() => navigation.navigate('Auth', { screen: 'SignIn' })}
          >
            <Text style={styles.signInButtonText}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    )
  }

  const currentOrder = orders[0]

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.navigate('HomeTab', { screen: 'Home' })}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>ORDER TRACKING</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
          <Ionicons name="notifications-outline" size={24} color="#000" />
        </TouchableOpacity>
      </View>

      <ScrollView 
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
      >
        {!currentOrder ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="receipt-outline" size={60} color="#CCC" />
            <Text style={styles.emptyText}>No orders yet</Text>
            <TouchableOpacity 
              style={styles.shopButton}
              onPress={() => navigation.navigate('HomeTab', { screen: 'Home' })}
            >
              <Text style={styles.shopButtonText}>Start Shopping</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.trackingContainer}>
            {(() => {
              const status = getOrderStatus(currentOrder.status)
              
              if (status.orderDeclined) {
                return (
                  <View style={styles.declinedContainer}>
                    <Ionicons name="close-circle" size={60} color="#F44336" />
                    <Text style={styles.declinedTitle}>ORDER DECLINED</Text>
                    <Text style={styles.declinedText}>
                      Your order #{currentOrder.order_number} has been declined.
                    </Text>
                    <Text style={styles.declinedSubtext}>
                      Please contact support for more information.
                    </Text>
                  </View>
                )
              }

              return (
                <View style={styles.timeline}>
                  {/* Order Placed */}
                  <View style={styles.timelineItem}>
                    <View style={[styles.dot, styles.activeDot]} />
                    <View style={styles.iconContainer}>
                      <Ionicons name="checkmark" size={20} color="#FFF" />
                    </View>
                    <View style={styles.timelineContent}>
                      <Text style={styles.timelineTitle}>ORDER PLACED</Text>
                      <Text style={styles.timelineDate}>
                        WE HAVE RECEIVED YOUR ORDER ON {formatDate(currentOrder.created_at)}
                      </Text>
                    </View>
                  </View>

                  {/* Order Confirmed */}
                  <View style={styles.timelineItem}>
                    <View style={[
                      styles.dot, 
                      status.orderConfirmed ? styles.activeDot : styles.greyDot
                    ]} />
                    <View style={[
                      styles.iconContainer,
                      !status.orderConfirmed && styles.greyIcon
                    ]}>
                      <Ionicons 
                        name="bag-handle" 
                        size={20} 
                        color={status.orderConfirmed ? "#FFF" : "#999"} 
                      />
                    </View>
                    <View style={styles.timelineContent}>
                      <Text style={[
                        styles.timelineTitle,
                        !status.orderConfirmed && styles.greyText
                      ]}>ORDER CONFIRMED</Text>
                      {status.orderConfirmed && (
                        <Text style={styles.timelineDate}>
                          ORDER HAS BEEN CONFIRMED ON {formatDate(currentOrder.created_at)}
                        </Text>
                      )}
                    </View>
                  </View>

                  {/* Out for Delivery */}
                  <View style={styles.timelineItem}>
                    <View style={[
                      styles.dot, 
                      status.outForDelivery ? styles.successDot : styles.greyDot
                    ]} />
                    <View style={[
                      styles.iconContainer,
                      status.outForDelivery ? styles.successIcon : styles.greyIcon
                    ]}>
                      <Ionicons 
                        name="car" 
                        size={20} 
                        color={status.outForDelivery ? "#FFF" : "#999"} 
                      />
                    </View>
                    <View style={styles.timelineContent}>
                      <Text style={[
                        styles.timelineTitle,
                        status.outForDelivery ? styles.successText : styles.greyText
                      ]}>OUT FOR DELIVERY</Text>
                      {status.outForDelivery && (
                        <Text style={styles.timelineDate}>
                          YOUR ORDER IS OUT FOR DELIVERY
                        </Text>
                      )}
                    </View>
                  </View>

                  {/* Order Arrived */}
                  <View style={styles.timelineItem}>
                    <View style={[
                      styles.dot, 
                      status.orderArrived ? styles.successDot : styles.greyDot
                    ]} />
                    <View style={[
                      styles.iconContainer,
                      status.orderArrived ? styles.successIcon : styles.greyIcon
                    ]}>
                      <Ionicons 
                        name="home" 
                        size={20} 
                        color={status.orderArrived ? "#FFF" : "#999"} 
                      />
                    </View>
                    <View style={styles.timelineContent}>
                      <Text style={[
                        styles.timelineTitle,
                        !status.orderArrived && styles.greyText
                      ]}>ORDER ARRIVED</Text>
                      {status.orderArrived && (
                        <Text style={styles.timelineDate}>
                          YOUR ORDER HAS BEEN DELIVERED
                        </Text>
                      )}
                    </View>
                  </View>

                  {/* Vertical Line */}
                  <View style={styles.verticalLine} />
                </View>
              )
            })()}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  guestContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  guestTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 20,
    marginBottom: 10,
  },
  guestText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
  },
  signInButton: {
    backgroundColor: '#FF69B4',
    paddingHorizontal: 40,
    paddingVertical: 12,
    borderRadius: 25,
  },
  signInButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 100,
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    marginTop: 20,
    marginBottom: 30,
  },
  shopButton: {
    backgroundColor: '#000',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  shopButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  trackingContainer: {
    backgroundColor: '#FFF',
    margin: 20,
    borderRadius: 15,
    padding: 20,
  },
  timeline: {
    position: 'relative',
  },
  verticalLine: {
    position: 'absolute',
    left: 19,
    top: 40,
    bottom: 40,
    width: 2,
    backgroundColor: '#E0E0E0',
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 40,
    position: 'relative',
  },
  dot: {
    position: 'absolute',
    left: 10,
    top: 10,
    width: 20,
    height: 20,
    borderRadius: 10,
    zIndex: 2,
  },
  activeDot: {
    backgroundColor: '#FF69B4',
  },
  successDot: {
    backgroundColor: '#4CAF50',
  },
  greyDot: {
    backgroundColor: '#E0E0E0',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FF69B4',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
    zIndex: 1,
  },
  successIcon: {
    backgroundColor: '#4CAF50',
  },
  greyIcon: {
    backgroundColor: '#E0E0E0',
  },
  timelineContent: {
    flex: 1,
    paddingTop: 5,
  },
  timelineTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 5,
  },
  timelineDate: {
    fontSize: 12,
    color: '#666',
    lineHeight: 18,
  },
  successText: {
    color: '#4CAF50',
  },
  greyText: {
    color: '#999',
  },
  declinedContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  declinedTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F44336',
    marginTop: 20,
    marginBottom: 10,
  },
  declinedText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  declinedSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
})

export default OrderTrackingScreen