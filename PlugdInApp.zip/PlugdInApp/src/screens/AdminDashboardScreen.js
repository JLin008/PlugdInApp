import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  ScrollView,
  Dimensions,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'
import { supabase } from '../services/supabase'
import { orderService } from '../services/orderService'
import { LineChart } from 'react-native-chart-kit'
import { useAuth } from '../services/authContext' // Add this import

const { width } = Dimensions.get('window')

const AdminDashboardScreen = () => {
  const navigation = useNavigation()
  const { signOut } = useAuth() // Add this
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [userCount, setUserCount] = useState(0)
  const [totalRevenue, setTotalRevenue] = useState(0)
  const [productsSold, setProductsSold] = useState(0)
  const [revenueData, setRevenueData] = useState([])

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Fetch all data in parallel
      const [users, revenue, products, dailyRevenue] = await Promise.all([
        fetchUserCount(),
        orderService.getTotalRevenue(),
        orderService.getProductsSoldCount(),
        orderService.getDailyRevenue(),
      ])

      setUserCount(users)
      setTotalRevenue(revenue)
      setProductsSold(products)
      setRevenueData(dailyRevenue)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const fetchUserCount = async () => {
    try {
      // Get users from auth.users table (requires service role key or RLS setup)
      // For now, we'll count from user_profiles which should match
      const { count, error } = await supabase
        .from('user_profiles')
        .select('*', { count: 'exact', head: true })

      if (error) throw error
      return count || 0
    } catch (error) {
      console.error('Error fetching user count:', error)
      
      // Alternative: try to get from orders (unique users)
      try {
        const { data, error } = await supabase
          .from('orders')
          .select('user_id')
          .not('user_id', 'is', null)
        
        if (error) throw error
        
        // Get unique user IDs
        const uniqueUsers = [...new Set(data?.map(order => order.user_id) || [])]
        return uniqueUsers.length
      } catch (err) {
        console.error('Alternative user count failed:', err)
        return 0
      }
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchDashboardData()
  }

  const getChartData = () => {
    if (!revenueData || revenueData.length === 0) {
      const emptyWeek = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']
      return {
        labels: emptyWeek,
        datasets: [{
          data: [0, 0, 0, 0, 0, 0, 0],
          color: (opacity = 1) => `rgba(249, 111, 111, ${opacity})`,
          strokeWidth: 3
        }]
      }
    }
    
    return {
      labels: revenueData.map(d => d.day.toUpperCase()),
      datasets: [{
        data: revenueData.map(d => parseFloat(d.revenue) || 0),
        color: (opacity = 1) => `rgba(249, 111, 111, ${opacity})`,
        strokeWidth: 3
      }]
    }
  }

  const handleSignOut = async () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut() // Use signOut from auth context
            } catch (error) {
              console.error('Sign out error:', error)
              Alert.alert('Error', 'Failed to sign out')
            }
          }
        }
      ]
    )
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Admin Dashboard</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FF69B4" />
        </View>
      </SafeAreaView>
    )
  }

  const chartData = getChartData()
  const hasRevenue = revenueData.some(d => parseFloat(d.revenue) > 0)

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Admin Dashboard</Text>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#FF69B4"
          />
        }
      >
        {/* Welcome Section */}
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeText}>Welcome Back,</Text>
          <Text style={styles.adminName}>Super Admin</Text>
        </View>

        {/* Stats Cards */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.statsContainer}
          contentContainerStyle={styles.statsContent}
        >
          {/* Total Users */}
          <View style={[styles.statCard, { backgroundColor: '#E8F5E9' }]}>
            <View style={styles.statIconContainer}>
              <Ionicons name="people-outline" size={28} color="#4CAF50" />
            </View>
            <Text style={styles.statLabel}>TOTAL USERS</Text>
            <Text style={styles.statValue}>{userCount.toLocaleString()}</Text>
          </View>

          {/* Total Revenue */}
          <View style={[styles.statCard, { backgroundColor: '#FFF3E0' }]}>
            <View style={styles.statIconContainer}>
              <Ionicons name="cash-outline" size={28} color="#FF9800" />
            </View>
            <Text style={styles.statLabel}>TOTAL REVENUE</Text>
            <Text style={styles.statValue}>${totalRevenue.toFixed(2)}</Text>
          </View>

          {/* Products Sold */}
          <View style={[styles.statCard, { backgroundColor: '#E3F2FD' }]}>
            <View style={styles.statIconContainer}>
              <Ionicons name="cube-outline" size={28} color="#2196F3" />
            </View>
            <Text style={styles.statLabel}>PRODUCTS SOLD</Text>
            <Text style={styles.statValue}>{productsSold.toLocaleString()}</Text>
          </View>
        </ScrollView>

        {/* Revenue Trend Graph */}
        <View style={styles.graphSection}>
          <Text style={styles.graphTitle}>REVENUE TREND (LAST 7 DAYS)</Text>
          
          <View style={{ marginHorizontal: -10 }}>
            <LineChart
              data={chartData}
              width={width - 40}
              height={220}
              chartConfig={{
                backgroundColor: '#FFF',
                backgroundGradientFrom: '#FFF',
                backgroundGradientTo: '#FFF',
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(249, 111, 111, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                style: {
                  borderRadius: 16,
                },
                propsForDots: {
                  r: '5',
                  strokeWidth: '2',
                  stroke: '#F96F6F',
                  fill: '#F96F6F',
                },
                propsForBackgroundLines: {
                  strokeDasharray: '',
                  stroke: '#E0E0E0',
                  strokeWidth: 1,
                },
                fillShadowGradient: '#FFE0E0',
                fillShadowGradientOpacity: 0.3,
                fillShadowGradientFrom: '#F96F6F',
                fillShadowGradientTo: '#FFFFFF',
                propsForLabels: {
                  fontSize: 9,
                },
              }}
              bezier
              style={{
                marginVertical: 8,
                borderRadius: 16,
                paddingRight: 35,
              }}
              withInnerLines={true}
              withOuterLines={false}
              withHorizontalLines={true}
              withVerticalLines={false}
              withDots={true}
              withShadow={false}
              fromZero={true}
              segments={4}
              formatYLabel={(value) => {
                if (value >= 1000) {
                  return `$${Math.round(value / 100) / 10}k`
                }
                return `$${Math.round(value)}`
              }}
            />
          </View>
          {!hasRevenue && (
            <Text style={styles.noRevenueNote}>
              No revenue data yet. Orders will appear here once processed.
            </Text>
          )}
        </View>

        {/* Action Buttons */}
        <View style={styles.actionSection}>
          <TouchableOpacity 
            style={[styles.actionButton, { backgroundColor: '#FF69B4' }]}
            onPress={() => navigation.navigate('Management', { 
              screen: 'NotificationManagement',
              params: { initialTab: 'notifications', openAdd: true }
            })}
          >
            <Ionicons name="megaphone-outline" size={24} color="#FFF" />
            <Text style={styles.actionButtonText}>ADD NOTIFICATION</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.actionButton, { backgroundColor: '#4CAF50' }]}
            onPress={() => navigation.navigate('Management', {
              screen: 'NotificationManagement',
              params: { initialTab: 'coupons', openAdd: true }
            })}
          >
            <Ionicons name="pricetag-outline" size={24} color="#FFF" />
            <Text style={styles.actionButtonText}>ADD COUPON</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.actionButton, { backgroundColor: '#FF1744' }]}
            onPress={handleSignOut}
          >
            <Ionicons name="log-out-outline" size={24} color="#FFF" />
            <Text style={styles.actionButtonText}>SIGN OUT</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    backgroundColor: '#FFF',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeSection: {
    paddingHorizontal: 20,
    paddingTop: 20,
    marginBottom: 20,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666',
  },
  adminName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
  },
  statsContainer: {
    marginBottom: 20,
  },
  statsContent: {
    paddingHorizontal: 20,
  },
  statCard: {
    width: 150,
    padding: 20,
    borderRadius: 15,
    marginRight: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
  },
  statIconContainer: {
    marginBottom: 15,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000',
  },
  graphSection: {
    backgroundColor: '#FFF',
    margin: 20,
    padding: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 2,
    overflow: 'hidden',
  },
  graphTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 20,
  },
  noRevenueNote: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    marginTop: 10,
    fontStyle: 'italic',
  },
  actionSection: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    borderRadius: 25,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 3,
  },
  actionButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10,
  },
})

export default AdminDashboardScreen