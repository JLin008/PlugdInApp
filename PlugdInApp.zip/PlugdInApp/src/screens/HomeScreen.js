import React, { useState, useEffect } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  FlatList,
  ActivityIndicator,
  Alert,
  Dimensions,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useAuth } from '../services/authContext'
import { supabase } from '../services/supabase'
import { useNavigation } from '@react-navigation/native'
import { Image as ExpoImage } from 'expo-image'
import { useCart } from '../services/cartContext'

const { width } = Dimensions.get('window')

const HomeScreen = () => {
  const { user } = useAuth()
  const { addToCart, profile, cartCount, updateCartQuantity, removeFromCart } = useCart()
  const navigation = useNavigation()
  const [popularProducts, setPopularProducts] = useState([])
  const [favorites, setFavorites] = useState([])
  const [loading, setLoading] = useState(true)
  const [cartItems, setCartItems] = useState({}) // Track quantities for each product

  useEffect(() => {
    fetchPopularProducts()
    if (user) {
      fetchFavorites()
      fetchCartItems()
    }
    
    // Subscribe to real-time product changes
    const subscription = supabase
      .channel('customer_products_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'products'
        },
        (payload) => {
          console.log('Customer app detected product change:', payload)
          // Refresh products when any change happens
          fetchPopularProducts()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [user])

  const fetchPopularProducts = async () => {
    try {
      // Get top 10 highest rated products
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('rating', { ascending: false })
        .order('review_count', { ascending: false })
        .limit(10)
      
      if (error) throw error
      setPopularProducts(data || [])
    } catch (error) {
      console.error('Error fetching products:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchFavorites = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('favorites')
        .select('product_id')
        .eq('user_id', user.id)
      
      if (error) throw error
      setFavorites(data?.map(f => f.product_id) || [])
    } catch (error) {
      console.error('Error fetching favorites:', error)
    }
  }

  const fetchCartItems = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('cart_items')
        .select('product_id, quantity')
        .eq('user_id', user.id)
      
      if (error) throw error
      
      // Convert to object for easy lookup
      const cartObj = {}
      data?.forEach(item => {
        cartObj[item.product_id] = item.quantity
      })
      setCartItems(cartObj)
    } catch (error) {
      console.error('Error fetching cart items:', error)
    }
  }

  const handleUpdateCartQuantity = async (productId, newQuantity) => {
    if (!user) {
      Alert.alert('Sign In Required', 'Please sign in to manage cart', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign In', onPress: () => navigation.navigate('Auth', { screen: 'SignIn' }) }
      ])
      return
    }

    try {
      if (newQuantity === 0) {
        await removeFromCart(productId)
        setCartItems(prev => {
          const updated = { ...prev }
          delete updated[productId]
          return updated
        })
      } else {
        await updateCartQuantity(productId, newQuantity)
        setCartItems(prev => ({
          ...prev,
          [productId]: newQuantity
        }))
      }
    } catch (error) {
      console.error('Error updating cart:', error)
      Alert.alert('Error', 'Failed to update cart')
    }
  }

  const toggleFavorite = async (productId) => {
    if (!user) {
      Alert.alert('Sign In Required', 'Please sign in to save favorites', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign In', onPress: () => navigation.navigate('Auth', { screen: 'SignIn' }) }
      ])
      return
    }

    const isFavorite = favorites.includes(productId)
    
    try {
      if (isFavorite) {
        // Remove from favorites
        const { error } = await supabase
          .from('favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('product_id', productId)
        
        if (error) throw error
        setFavorites(favorites.filter(id => id !== productId))
      } else {
        // Add to favorites
        const { error } = await supabase
          .from('favorites')
          .insert([{ user_id: user.id, product_id: productId }])
        
        if (error) throw error
        setFavorites([...favorites, productId])
      }
    } catch (error) {
      console.error('Error toggling favorite:', error)
      Alert.alert('Error', 'Failed to update favorites')
    }
  }

  // Get first letter of email for avatar
  const getInitial = () => {
    if (!user) return 'G'
    const email = profile?.email || user?.email || 'U'
    return email.charAt(0).toUpperCase()
  }

  // Get display name
  const getDisplayName = () => {
    if (!user) return 'Guest'
    return profile?.name || user?.email?.split('@')[0] || 'User'
  }

  const renderProduct = ({ item }) => {
    const isFavorite = favorites.includes(item.id)
    const discountedPrice = item.discount > 0 
      ? (item.price - (item.price * item.discount / 100)).toFixed(2)
      : null

    return (
      <TouchableOpacity 
        style={styles.productCard}
        onPress={() => navigation.navigate('ProductDetail', { productId: item.id })}
      >
        <TouchableOpacity 
          style={styles.favoriteButton}
          onPress={() => toggleFavorite(item.id)}
        >
          <Ionicons 
            name={isFavorite ? "heart" : "heart-outline"} 
            size={20} 
            color={isFavorite ? "#FF69B4" : "#888"} 
          />
        </TouchableOpacity>
        
        <ExpoImage 
          source={{ uri: item.image_url }} 
          style={styles.productImage}
          contentFit="cover"
          transition={200}
          placeholder={require('../assets/images/plugd-logo.png')}
        />
        
        <Text style={styles.productName} numberOfLines={1}>{item.name}</Text>
        <Text style={styles.productBrand} numberOfLines={1}>{item.brand}</Text>
        
        <View style={styles.ratingContainer}>
          {[...Array(5)].map((_, i) => (
            <Ionicons 
              key={i} 
              name="star" 
              size={12} 
              color={i < Math.floor(item.rating) ? "#FFD700" : "#DDD"} 
            />
          ))}
          <Text style={styles.ratingText}>({item.review_count})</Text>
        </View>
        
        <View style={styles.priceContainer}>
          {discountedPrice ? (
            <>
              <Text style={styles.originalPrice}>${item.price}</Text>
              <Text style={styles.discountedPrice}>${discountedPrice}</Text>
            </>
          ) : (
            <Text style={styles.price}>${item.price}</Text>
          )}
        </View>
        
        {cartItems[item.id] ? (
          <View style={styles.quantityControl}>
            <TouchableOpacity 
              style={styles.quantityButton}
              onPress={() => handleUpdateCartQuantity(item.id, cartItems[item.id] - 1)}
            >
              <Ionicons name="remove" size={16} color="#000" />
            </TouchableOpacity>
            <Text style={styles.quantityText}>{cartItems[item.id]}</Text>
            <TouchableOpacity 
              style={styles.quantityButton}
              onPress={() => handleUpdateCartQuantity(item.id, cartItems[item.id] + 1)}
            >
              <Ionicons name="add" size={16} color="#000" />
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity 
            style={styles.addToCartButton}
            onPress={async () => {
              if (!user) {
                Alert.alert('Sign In Required', 'Please sign in to add items to cart', [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Sign In', onPress: () => navigation.navigate('Auth', { screen: 'SignIn' }) }
                ])
                return
              }
              
              try {
                await addToCart(item.id)
                setCartItems(prev => ({
                  ...prev,
                  [item.id]: 1
                }))
              } catch (error) {
                Alert.alert('Error', error.message || 'Failed to add to cart')
              }
            }}
          >
            <Text style={styles.addToCartText}>ADD TO CART</Text>
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header with black background */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <View style={styles.leftHeader}>
            <Image 
              source={require('../assets/images/plugd-logo.png')}
              style={styles.headerLogo}
              resizeMode="contain"
            />
            <View style={styles.userInfo}>
              <Text style={styles.welcomeText}>WELCOME BACK</Text>
              <Text style={styles.userName}>{getDisplayName().toUpperCase()}</Text>
            </View>
          </View>
          <View style={styles.headerButtons}>
            <TouchableOpacity 
              onPress={() => navigation.navigate('AllProducts', { focusSearch: true })}
              style={styles.searchButton}
            >
              <Ionicons name="search-outline" size={24} color="#999" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
              <Ionicons name="notifications-outline" size={24} color="#999" />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.cartIconContainer}
              onPress={() => navigation.navigate('Cart')}
            >
              <Ionicons name="cart-outline" size={24} color="#999" />
              {cartCount > 0 && (
                <View style={styles.cartBadge}>
                  <Text style={styles.cartBadgeText}>{cartCount}</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Promotional Banner */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.bannerContainer}
        >
          <TouchableOpacity 
            style={styles.promoBanner}
            onPress={() => Alert.alert('Promo Code', 'Use code FIRST30 for 30% off your first order!')}
          >
            <Image 
              source={require('../assets/images/discount.png')} 
              style={styles.promoImageFull}
              resizeMode="contain"
            />
          </TouchableOpacity>
        </ScrollView>

        {/* Popular Products */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>POPULAR PRODUCTS</Text>
          <TouchableOpacity onPress={() => navigation.navigate('AllProducts')}>
            <Text style={styles.seeAllText}>SEE ALL</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator size="large" color="#FF69B4" style={styles.loader} />
        ) : (
          <FlatList
            data={popularProducts}
            renderItem={renderProduct}
            keyExtractor={(item) => item.id.toString()}
            numColumns={2}
            columnWrapperStyle={styles.productRow}
            scrollEnabled={false}
            contentContainerStyle={styles.productsContainer}
          />
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  headerContainer: {
    backgroundColor: '#000',
    paddingBottom: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  leftHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  headerLogo: {
    width: 50,
    height: 50,
    marginRight: 12,
  },
  userInfo: {
    flex: 1,
  },
  welcomeText: {
    fontSize: 12,
    color: '#999',
    fontWeight: '600',
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF69B4',
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  searchButton: {
    padding: 4,
  },
  cartIconContainer: {
    position: 'relative',
  },
  cartBadge: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#FF69B4',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 5,
  },
  cartBadgeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  bannerContainer: {
    paddingHorizontal: 20,
    marginBottom: 25,
    marginTop: 20,
  },
  promoBanner: {
    borderRadius: 20,
    width: width - 40,
    height: 150,
    overflow: 'hidden',
  },
  promoImageFull: {
    width: '100%',
    height: '100%',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  seeAllText: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '600',
  },
  productsContainer: {
    paddingBottom: 20,
  },
  productRow: {
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  productCard: {
    width: (width - 50) / 2,
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 12,
    marginBottom: 15,
  },
  favoriteButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  productImage: {
    width: '100%',
    height: 120,
    borderRadius: 10,
    marginBottom: 10,
  },
  productName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
    marginBottom: 4,
  },
  productBrand: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingText: {
    fontSize: 10,
    color: '#666',
    marginLeft: 5,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  originalPrice: {
    fontSize: 14,
    color: '#888',
    textDecorationLine: 'line-through',
    marginRight: 8,
  },
  discountedPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF69B4',
  },
  addToCartButton: {
    backgroundColor: '#000',
    borderRadius: 8,
    paddingVertical: 8,
    alignItems: 'center',
  },
  addToCartText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 4,
  },
  quantityButton: {
    width: 28,
    height: 28,
    borderRadius: 6,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  quantityText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
    marginHorizontal: 15,
  },
  loader: {
    marginTop: 50,
  },
})

export default HomeScreen