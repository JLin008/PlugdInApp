import React from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'

const TermsAndConditionsScreen = () => {
  const navigation = useNavigation()

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>TERMS AND CONDITIONS</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
          <Ionicons name="notifications-outline" size={24} color="#000" />
        </TouchableOpacity>
      </View>

      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.title}>TERMS AND CONDITIONS</Text>
        
        <Text style={styles.paragraph}>
          BY USING THE PLUG'D IN MOBILE APPLICATION, YOU AGREE TO THESE TERMS AND CONDITIONS. PLUG'D IN CONNECTS CUSTOMERS, DISPENSARIES, AND DRIVERS FOR LEGAL CANNABIS DELIVERY. YOU MUST BE AT LEAST 21 YEARS OLD AND LOCATED IN A REGION WHERE CANNABIS USE IS LEGAL. CUSTOMERS ARE RESPONSIBLE FOR PROVIDING VALID ID UPON DELIVERY AND COMPLYING WITH LOCAL LAWS. DRIVERS MUST MEET LEGAL DELIVERY REQUIREMENTS AND FOLLOW ALL SAFETY AND VERIFICATION PROTOCOLS. DISPENSARIES MUST BE LICENSED AND ARE ACCOUNTABLE FOR PRODUCT COMPLIANCE AND ACCURACY. ORDERS ARE SUBJECT TO AVAILABILITY, AND DELIVERY MAY BE DENIED IF ID IS INVALID OR UNSAFE CONDITIONS ARE PRESENT. PRICES INCLUDE APPLICABLE TAXES AND FEES, AND PAYMENTS ARE SECURELY PROCESSED. MISUSE OF THE APP, FALSE INFORMATION, OR ILLEGAL ACTIVITY MAY RESULT IN ACCOUNT SUSPENSION. PLUG'D IN IS NOT LIABLE FOR DELIVERY DELAYS OR INDIRECT DAMAGES. YOUR INFORMATION IS HANDLED ACCORDING TO OUR PRIVACY POLICY. WE MAY UPDATE THESE TERMS AT ANY TIME, AND CONTINUED USE OF THE APP IMPLIES ACCEPTANCE OF ANY CHANGES.
        </Text>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  content: {
    flex: 1,
    backgroundColor: '#FFF',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 20,
  },
  paragraph: {
    fontSize: 14,
    color: '#666',
    lineHeight: 24,
    textAlign: 'justify',
    letterSpacing: -0.3,
  },
})

export default TermsAndConditionsScreen