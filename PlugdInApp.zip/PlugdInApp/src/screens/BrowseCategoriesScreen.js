import React from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Image,
} from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import { useNavigation } from '@react-navigation/native'

const BrowseCategoriesScreen = () => {
  const navigation = useNavigation()

  const categories = [
    {
      id: 1,
      name: 'PREMIUM FLOWER',
      description: 'TOP-SHELF CANNABIS FLOWER STRAINS',
      priceRange: 'FROM $25 - $65',
      image: require('../assets/images/premium-flower.png'),
      bgColor: '#E8F5E9',
    },
    {
      id: 2,
      name: 'EDIBLES',
      description: 'DELICIOUS, DISCREET & LONG-LASTING',
      priceRange: 'FROM $25 - $60',
      image: require('../assets/images/edibles.png'),
      bgColor: '#FCE4EC',
    },
    {
      id: 3,
      name: 'CONCENTRATES',
      description: 'POTENT EXTRACTS FOR EXPERIENCED USERS',
      priceRange: 'FROM $25 - $80',
      image: require('../assets/images/concentrates.png'),
      bgColor: '#F3E5F5',
    },
    {
      id: 4,
      name: 'VAPES',
      description: 'CARTRIDGES & DISPOSABLES',
      priceRange: 'FROM $25 - $65',
      image: require('../assets/images/sativa-vape-pen.png'),
      bgColor: '#E3F2FD',
    },
    {
      id: 5,
      name: 'PRE-ROLLS',
      description: 'READY-TO-SMOKE JOINTS',
      priceRange: 'FROM $25 - $50',
      image: require('../assets/images/og-kush-prerolls.png'),
      bgColor: '#FFF3E0',
    },
    {
      id: 6,
      name: 'TOPICALS',
      description: 'BALMS, CREAMS & LOTIONS',
      priceRange: 'FROM $25 - $60',
      image: require('../assets/images/pain-relief-cream.png'),
      bgColor: '#E0F2F1',
    },
  ]

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>BROWSE CATEGORIES</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Ionicons name="search-outline" size={20} color="#888" />
            <TextInput
              style={styles.searchInput}
              placeholder="SEARCH HERE"
              placeholderTextColor="#888"
              onFocus={() => Alert.alert('Coming Soon', "Search screen doesn't exist yet")}
            />
          </View>
          <TouchableOpacity 
            style={styles.filterButton}
            onPress={() => Alert.alert('Coming Soon', "Filter screen doesn't exist yet")}
          >
            <Ionicons name="options-outline" size={20} color="#FFF" />
          </TouchableOpacity>
        </View>

        <Text style={styles.pageTitle}>BROWSE CATEGORIES</Text>

        {/* Category Grid */}
        <View style={styles.categoryGrid}>
          {categories.map((category) => (
            <TouchableOpacity
              key={category.id}
              style={[styles.categoryCard, { backgroundColor: category.bgColor }]}
              onPress={() => Alert.alert('Coming Soon', "Screen doesn't exist yet")}
            >
              <Image 
                source={category.image} 
                style={styles.categoryImage}
                resizeMode="contain"
              />
              <Text style={styles.categoryName}>{category.name}</Text>
              <Text style={styles.categoryDescription}>{category.description}</Text>
              <Text style={styles.priceRange}>{category.priceRange}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEE',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 20,
    marginBottom: 20,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 25,
    paddingHorizontal: 15,
    height: 45,
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
  },
  filterButton: {
    width: 45,
    height: 45,
    backgroundColor: '#FF69B4',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pageTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  categoryGrid: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  categoryCard: {
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    minHeight: 120,
  },
  categoryEmoji: {
    fontSize: 32,
    marginBottom: 10,
  },
  categoryImage: {
    width: 50,
    height: 50,
    marginBottom: 10,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 5,
  },
  categoryDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 10,
  },
  priceRange: {
    fontSize: 12,
    color: '#888',
    fontWeight: '600',
  },
})

export default BrowseCategoriesScreen