import React, { useState, useRef, useEffect } from 'react'
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native'
import { Ionicons } from '@expo/vector-icons'
import { supabase } from '../services/supabase'
import { CommonActions } from '@react-navigation/native'

const ResetPasswordVerifyScreen = ({ route, navigation }) => {
  const [code, setCode] = useState(['', '', '', '', '', ''])
  const [loading, setLoading] = useState(false)
  const inputs = useRef([])
  const email = route.params?.email || ''

  useEffect(() => {
    if (!email) {
      Alert.alert('Error', 'Email not found. Please try again.', [
        { text: 'OK', onPress: () => navigation.navigate('ForgotPassword') }
      ])
    }
  }, [email])

  const handleCodeChange = (value, index) => {
    const newCode = [...code]
    newCode[index] = value

    setCode(newCode)

    // Auto-focus next input
    if (value && index < 5) {
      inputs.current[index + 1]?.focus()
    }
  }

  const handleKeyPress = (e, index) => {
    if (e.nativeEvent.key === 'Backspace' && !code[index] && index > 0) {
      inputs.current[index - 1]?.focus()
    }
  }

  const handleVerify = async () => {
    const fullCode = code.join('')
    if (fullCode.length !== 6) {
      Alert.alert('Error', 'Please enter a complete 6-digit code')
      return
    }

    setLoading(true)
    try {
      // For password reset, we need to verify the recovery code
      const { data, error } = await supabase.auth.verifyOtp({
        email: email,
        token: fullCode,
        type: 'recovery',
      })

      if (error) {
        console.error('OTP verification error:', error)
        Alert.alert('Error', 'Invalid or expired verification code')
        setLoading(false)
        return
      }

      // If successful, user is now authenticated
      // Make sure we navigate to SetNewPassword, not Home
      if (data && data.session) {
        // User is authenticated, navigate to set new password
        navigation.dispatch(
          CommonActions.reset({
            index: 1,
            routes: [
              { name: 'ForgotPassword' },
              { name: 'SetNewPassword', params: { email: email } }
            ],
          })
        )
      } else {
        // If no session, still navigate to set new password
        navigation.navigate('SetNewPassword', { email: email })
      }
    } catch (error) {
      console.error('Verification error:', error)
      Alert.alert('Error', 'Failed to verify code')
    } finally {
      setLoading(false)
    }
  }

  const handleResend = async () => {
    if (!email) {
      Alert.alert('Error', 'Email not found. Please try again.')
      return
    }

    setLoading(true)
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email)

      if (error) {
        Alert.alert('Error', error.message)
      } else {
        Alert.alert('Success', 'Verification code has been resent to your email')
        // Clear the code inputs
        setCode(['', '', '', '', '', ''])
        // Reset focus to first input
        inputs.current[0]?.focus()
      }
    } catch (error) {
      Alert.alert('Error', 'An unexpected error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="chevron-back" size={24} color="#fff" />
      </TouchableOpacity>

      <View style={styles.content}>
        <Text style={styles.title}>Reset Password</Text>
        <Text style={styles.subtitle}>
          We've sent a verification code to your email. Check your inbox and enter the code here
        </Text>

        <View style={styles.codeContainer}>
          {code.map((digit, index) => (
            <TextInput
              key={index}
              ref={(ref) => (inputs.current[index] = ref)}
              style={styles.codeInput}
              value={digit}
              onChangeText={(value) => handleCodeChange(value, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
              keyboardType="numeric"
              maxLength={1}
              selectTextOnFocus
            />
          ))}
        </View>

        <TouchableOpacity
          style={styles.verifyButton}
          onPress={handleVerify}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.verifyButtonText}>Verify Code</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity onPress={handleResend} disabled={loading}>
          <Text style={styles.resendText}>
            Did not receive code? <Text style={styles.resendLink}>Resend</Text>
          </Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  backButton: {
    position: 'absolute',
    top: 50,
    left: 20,
    zIndex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  codeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  codeInput: {
    width: 45,
    height: 50,
    backgroundColor: '#2a2a2a',
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#FF69B4',
    color: '#fff',
    fontSize: 20,
    textAlign: 'center',
  },
  verifyButton: {
    backgroundColor: '#333',
    borderRadius: 10,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  verifyButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resendText: {
    color: '#666',
    textAlign: 'center',
    fontSize: 14,
  },
  resendLink: {
    color: '#FF69B4',
    fontWeight: 'bold',
  },
})

export default ResetPasswordVerifyScreen